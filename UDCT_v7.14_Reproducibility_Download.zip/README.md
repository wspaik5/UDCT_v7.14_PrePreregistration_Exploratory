# UDCT v7.14 — Exploratory QUMOND Hessian and Phase-Space Consistency Tests (Steps 01–50)

**Status:** First public exploratory working paper; not preregistered, not peer reviewed.

**Reserved Zenodo DOI:** https://doi.org/10.5281/zenodo.23663161 (becomes registered upon publication)

**GitHub:** https://github.com/wspaik5/UDCT_v7.14_PrePreregistration_Exploratory

## Contents
- `UDCT_v7.14_Comprehensive_Detailed_Research_Paper_Steps01_50.pdf` — PRIMARY detailed 20-page research paper with step-by-step archival analysis, mathematics, interpretation and expanded references.
- `UDCT_v7.14_Exploratory_Working_Paper_Steps01_50.pdf` — optional 4-page executive summary, NOT the primary paper.
- `original_archives/` — byte-preserved original user-uploaded ZIPs, Steps 01–25 and 26–50.
- `steps_26_50/` — extracted original individual Step 26–50 packages.
- `figures/` — figures redrawn from archived CSV values; **not** new simulation results.
- `SHA256SUMS.txt` — checksums of bundled files.

## Reproduction
Install requirements from each Step subfolder and follow that Step's README. Scripts have different entrypoints and dependencies; no single all-50 rerun is claimed. For example, Step 50: `cd steps_26_50/Step_50 && pip install -r requirements.txt && python step50.py`. Some scripts depend on previous step output or archived reference kernels; consult the local README. The Step 01–25 archive retains its original flat file names and must be inspected by experiment rather than assuming a single runnable pipeline.

## Scientific boundaries
- 3D Hessian diagnostics are distinct from spherical DF inversion.
- Computing Hessians is not equivalent to implementing Milgrom (2023) GQUMOND.
- p=1.5 cancels a leading asymptotic coefficient; full DF sign at equality is not settled by that coefficient.
- Step 50 tangency is local in a finite energy-label window, not a global physical threshold.
- No complete individual-star Hydrus I velocity likelihood fit is claimed.

## Provenance
Figures use archived Step 46 and Step 50 CSV files. The original ZIPs are retained without modification. The paper summarizes rather than independently reexecutes all steps.
