"""Step 46: fixed-energy 2D OM sign map; direct quadrature in log radius."""
from pathlib import Path
import numpy as np, csv, json
from scipy.integrate import solve_ivp
from numpy.polynomial.legendre import leggauss
from math import pi,sqrt,log
D=Path(__file__).resolve().parent
G=4.30091e-3;a=53.3;M=32730.
a0=1.2e-10*3.085677581491367e16/1e6
C=1/(sqrt(8)*pi*pi)

def gravity(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 g=.5*n+np.sqrt(.25*n*n+a0*n)
 gp=dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
 return g,gp

def rho2phi(r,p,ra):
 y=(r/a)**p; rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y));Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 d1=rho*L;d2=rho*(L*L+Lp)
 if np.isfinite(ra):
  inv=1/(ra*a)**2;h=1+r*r*inv
  d1,d2=h*d1+2*r*rho*inv,h*d2+4*r*d1*inv+2*rho*inv
 g,gp=gravity(r)
 return (d2*g-d1*gp)/g**3

def one_radius(rr,ps,ras,n,outer=1e9):
 r0=rr*a;umax=np.log(outer/rr)
 sol=solve_ivp(lambda u,v:[gravity(r0*np.exp(u))[0]*r0*np.exp(u)],(0,umax),[0.],rtol=1e-11,atol=1e-12,dense_output=True)
 if not sol.success:raise RuntimeError(sol.message)
 x,w=leggauss(n);t=(x+1)*np.sqrt(umax)/2;w=w*np.sqrt(umax)/2
 u=t*t;r=r0*np.exp(u);delta=sol.sol(u)[0];g,_=gravity(r)
 weight=2*t*g*r/np.sqrt(delta)*w
 out=np.empty((len(ps),len(ras)))
 for i,p in enumerate(ps):
  for j,ra in enumerate(ras):out[i,j]=C*np.dot(weight,rho2phi(r,p,ra))
 return out

def main():
 ps=np.array([1.45,1.48,1.49,1.495,1.5,1.501,1.505,1.51,1.55,1.6,2.0])
 ras=np.array([0.4,0.5,0.6,0.65,0.75,1.0,1.5,2.0,4.0,np.inf])
 rrs=np.geomspace(1e-7,1e2,33)
 rows=[];maxdiff=0
 for k,rr in enumerate(rrs):
  low=one_radius(rr,ps,ras,96);hi=one_radius(rr,ps,ras,192)
  maxdiff=max(maxdiff,float(np.max(np.abs(hi-low))))
  for i,p in enumerate(ps):
   for j,ra in enumerate(ras):
    rows.append({'p':p,'ra_over_a':('inf' if np.isinf(ra) else ra),'r_energy_over_a':rr,'f_96':low[i,j],'f_192':hi[i,j],'abs_diff':abs(hi[i,j]-low[i,j]),'sign':('negative' if hi[i,j]<0 else 'positive')})
  print(f'{k+1}/{len(rrs)}',flush=True)
 with (D/'om_2d_scan.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 summary=[]
 for p in ps:
  for ra in ras:
   vals=[x for x in rows if x['p']==p and x['ra_over_a']==('inf' if np.isinf(ra) else ra)]
   neg=[x for x in vals if x['f_192']<0]
   summary.append({'p':p,'ra_over_a':vals[0]['ra_over_a'],'negative_count':len(neg),'min_f':min(x['f_192'] for x in vals),'first_negative_r_over_a':(neg[0]['r_energy_over_a'] if neg else ''),'last_negative_r_over_a':(neg[-1]['r_energy_over_a'] if neg else '')})
 with (D/'sign_map_summary.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 meta={'cases':len(rows),'negative_cases':int(sum(x['f_192']<0 for x in rows)),'max_abs_quadrature_difference':maxdiff,'n_p':len(ps),'n_ra':len(ras),'n_energy':len(rrs),'caveat':'Finite sampled energies; zero negatives does not certify globally nonnegative DF; same analytic gravity and OM inversion used at both quadrature orders.'}
 (D/'summary.json').write_text(json.dumps(meta,indent=2))
 print(meta)
 print('map p/ra counts:')
 for p in ps:print(p,[s['negative_count'] for s in summary if s['p']==p])
if __name__=='__main__':main()
