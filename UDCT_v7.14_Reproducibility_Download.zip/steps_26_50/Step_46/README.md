# UDCT v7.14 — Step 46: OM anisotropy sign map

Status: **exploratory, before preregistration**. No Hydrus I individual-star likelihood fitting.

## Purpose
Map signs of an Osipkov–Merritt (OM) distribution function in an **isolated spherical QUMOND** potential sourced by a Plummer mass distribution. Tracer density: rho(r) = [1+(r/a)^p]^(-5/p). OM augmented density: (1+r^2/r_a^2) rho(r).

## Computation
`python step46.py` regenerates `om_2d_scan.csv`, `sign_map_summary.csv`, and `summary.json`.

- 11 p values: 1.45, 1.48, 1.49, 1.495, 1.5, 1.501, 1.505, 1.51, 1.55, 1.6, 2.0
- 10 anisotropy radii r_a/a: 0.4, 0.5, 0.6, 0.65, 0.75, 1.0, 1.5, 2.0, 4.0, infinity (isotropic)
- 33 log-spaced energy-associated turning radii from 1e-7 a to 1e2 a
- 3630 f(Q) values, of which 800 are negative
- 96- and 192-point Gauss–Legendre quadrature. No sign disagreements; largest absolute difference 2.87275e-5 in the chosen normalized units.

## Method
The force g(r) and derivative dg/dr are analytic; potential differences are computed by a high-accuracy ODE integration over log radius. The OM augmented density derivatives are analytic. The Eddington/OM Abel inverse integral is computed over log radius with a square-root-endpoint-removing substitution. Outer numerical radius is 1e9 a. `r_energy_over_a` labels the radial point where Q=Phi(r), **not** an observed star radius.

## Interpretation and limitations
- p=1.5 is **not** a universal positivity boundary for anisotropic models. For r_a/a=0.4, negative samples occur even at p=1.45–1.5.
- 0 negative samples on a finite energy grid does not prove f(Q)>=0 at all energies.
- The map is a grid of signs, not a precise contour or a mathematically certified global positivity region.
- All runs use the same potential, tracer family, and inversion assumptions; varying quadrature order tests numerical convergence, not physical correctness.
- Extremely small values near zero should be checked using more precision and independently evaluated inversion/boundary terms.
- The outer cutoff has not been certified by a strict tail bound for every grid point.
- OM inversion assumes the distribution depends on Q=E-L^2/(2r_a^2) in the specified potential. Other anisotropy models need separate tests.
- This does **not** falsify MOND/QUMOND in general and is not an observational test using the full Hydrus I stellar-velocity catalog.

## Outputs
- `step46.py`: reproducible code
- `om_2d_scan.csv`: all 3630 values with 96/192 quadrature comparisons
- `sign_map_summary.csv`: negative counts, minimum f, first/last negative sampled radii for each (p,ra)
- `summary.json`: machine-readable metadata
- `requirements.txt`: dependencies

## Next
Focus on near-zero cells and actual zero-crossing bracketing in energy; compare with an independent inversion formula, then continue to 3D external field and re-audit v7.13's 24 *candidates* (not 24 proven transitions).
