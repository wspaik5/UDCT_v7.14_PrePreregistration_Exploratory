# UDCT v7.14 Step 31 — QUMOND DF sign and forward reconstruction audit

Exploratory, not preregistration. Actual numerical calculations. Source is the locally preserved Step 30 `step30.py`, included here as `step30_reference.py` for portable reproduction. Execute `python step31.py` with NumPy/SciPy. Outputs `tail_and_tolerance.csv`, `density_reconstruction.csv`, and `results.json`.

## Test
- Isolated spherical QUMOND, simple nu, Plummer stellar source and tracer, a=53.3 pc, M=32730 Msun.
- Isotropic and Osipkov–Merritt r_a=a.
- Compare unbounded-potential DF inversion integrals terminated at r/a=1e4, 1e6, 1e8 and stricter quadrature tolerance.
- Forward density reconstruction rho_aug(Phi) = 4*pi*sqrt(2) integral_Phi^infty f(E) sqrt(E-Phi) dE using 145 sampled energy points up to r/a=1e6.

## Findings
- At energy corresponding to r/a=0.025, 0.05, 0.1, DF remains negative for both q=inf and q=1. Tail and quadrature sensitivity for those values is less than ~2e-7 relative.
- Forward density reconstruction near center (r/a <=0.2) agrees to ~0.08% or better, but error is several percent at r/a=1 to 3 and ~5-11% at r/a=10. Therefore full reconstruction convergence is NOT established.
- One integration warning was emitted by scipy for one sampled integral; retain it in the audit trail.
- These findings concern a particular imposed tracer profile and potential; do not infer QUMOND/MOND/UDCT general failure, 3D EFE behavior, or real Hydrus I fit.

## Reproducibility
- The script uses its adjacent `step30_reference.py` (rather than an absolute original location). All numerical output is regenerated on execution.
- Requires numpy, scipy. Code is exploratory, not a preregistered confirmatory test.
