"""Independent sensitivity and forward-density audit of Step 30, exploratory."""
import numpy as np, csv, json
from scipy.integrate import quad
from scipy.interpolate import PchipInterpolator
from pathlib import Path
P=Path(__file__).resolve().parent
source=P/'step30_reference.py'
# Load only definitions, do not execute its 473-point scan.
code=source.read_text().split('qs=[.5,')[0]
ns={'__file__':str(source)}; exec(compile(code,str(source),'exec'),ns)
a=ns['a']; phi=ns['phi']; inv=ns['inv']; g=ns['g']; dg=ns['dg']; derivs=ns['derivs']; C=ns['C']; logr=ns['logr']
def evaldf(E,q,rtop=1e8,epsrel=2e-6):
    le=float(inv(E)); top=np.log(a*rtop); tmax=np.sqrt(max(top-le,0))
    def integrand(t):
        if t<1e-9:t=1e-9
        lr=le+t*t; r=np.exp(lr); gg=g(r); gp=dg(r); rp,rpp=derivs(r,q)
        rho2=(rpp*gg-rp*gp)/gg**3
        delta=max(float(phi(lr)-E),1e-28)
        return rho2*gg*2*t*r/np.sqrt(delta)
    return C*quad(integrand,0,tmax,epsabs=1e-11,epsrel=epsrel,limit=220)[0]
rows=[]
for q in [np.inf,1.0]:
 for rv in [.025,.05,.1,.2,.5,1.,3.]:
  E=float(phi(np.log(a*rv)))
  vs=[evaldf(E,q,rtop=t) for t in [1e4,1e6,1e8]]
  vprec=evaldf(E,q,rtop=1e8,epsrel=2e-8)
  rows.append({'q':str(q),'r_over_a':rv,'E':E,'f_tail_1e4':vs[0],'f_tail_1e6':vs[1],'f_tail_1e8':vs[2],'f_tight':vprec,'rel_tail_change':abs(vs[2]-vs[1])/max(abs(vs[2]),1e-20),'rel_tolerance_change':abs(vprec-vs[2])/max(abs(vprec),1e-20)})
with (P/'tail_and_tolerance.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Forward reconstruction: rho_aug(Phi)=4 pi sqrt(2) int_Phi^inf f(E) sqrt(E-Phi) dE
# Evaluate f on log-radius grid, then integrate in radius, with energy integration via trapezoid.
recon=[]
for q in [np.inf,1.0]:
 radii=a*np.geomspace(0.01,1e6,145)
 energies=np.array([float(phi(np.log(r))) for r in radii]); vals=np.array([evaldf(E,q,epsrel=1e-5) for E in energies])
 for rv in [.05,.1,.2,.5,1.,3.,10.]:
  E0=float(phi(np.log(a*rv)))
  # integral on E grid with exact E0 knot; f(E0) evaluated directly
  Evec=np.r_[E0,energies[energies>E0]]
  fvec=np.r_[evaldf(E0,q),vals[energies>E0]]
  rho_rec=4*np.pi*np.sqrt(2)*np.trapezoid(fvec*np.sqrt(np.maximum(Evec-E0,0)),Evec)
  x=rv; rho_target=(1+x*x)**(-2.5)*(1 if np.isinf(q) else 1+x*x/q**2)
  recon.append({'q':str(q),'r_over_a':rv,'rho_target_normalized':rho_target,'rho_reconstructed':rho_rec,'relative_error':(rho_rec-rho_target)/rho_target})
with (P/'density_reconstruction.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(recon[0]));w.writeheader();w.writerows(recon)
summary={'source_step30':str(source),'audit':'tail 1e4/1e6/1e8 and quadrature tolerance; forward density reconstruction using sampled DF','tail_and_tolerance':rows,'density_reconstruction':recon,'limitations':['Forward reconstruction uses finite energy maximum r/a=1e6 and 145-point logarithmic radius grid; low-density outer points sensitive to truncation','DF still depends on source potential and derivative formulas; no external 3D field','A negative f is incompatible with nonnegative isotropic/OM DF under this specific prescribed tracer and potential, not a general QUMOND no-go','Not Hydrus I star-by-star fit or preregistration']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
print('TAIL RESULTS')
for r in rows:print(r['q'],r['r_over_a'],f"f={r['f_tail_1e8']:.6g}",f"tailrel={r['rel_tail_change']:.2g}",f"tolrel={r['rel_tolerance_change']:.2g}")
print('RECONSTRUCTION')
for r in recon:print(r['q'],r['r_over_a'],f"relative={r['relative_error']:.3g}")
