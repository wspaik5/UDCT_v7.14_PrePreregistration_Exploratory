"""Independent rerun of Step38's specified inversion, focused on p=3/2.
All numbers dimensionless in the DF's density normalization rho0=1.
"""
import csv, json
from pathlib import Path
import numpy as np
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from numpy.polynomial.legendre import leggauss
P=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=32730.
a0=1.2e-10*3.085677581491367e16/1e6
C=1/(np.sqrt(8)*np.pi**2)
def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+np.sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def deriv(r,p):
 y=(r/a)**p; rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y))
 Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 return rho*L,rho*(L*L+Lp)
x=np.linspace(np.log(1e-10*a),np.log(1e10*a),160001)
r=np.exp(x); phi=cumulative_trapezoid(g(r)*r,x,initial=0)
F=PchipInterpolator(x,phi)
def calc(rv,p,N):
 r0=rv*a; xmax=np.log(1e9*a/r0)
 z,w=leggauss(N); t=(z+1)*np.sqrt(xmax)/2
 rr=r0*np.exp(t*t); gr=g(rr); d1,d2=deriv(rr,p)
 d2rho=(d2*gr-d1*gp(rr))/gr**3
 delta=F(np.log(rr))-float(F(np.log(r0)))
 integrand=d2rho*gr*2*t*rr/np.sqrt(delta)
 return float(C*np.dot(w,integrand)*np.sqrt(xmax)/2)
ps=[1.45,1.49,1.499,1.5,1.501,1.505,1.51,1.525,1.55]
rs=[1e-6,1e-5,1e-4,1e-3,1e-2,1e-1,1,10,100]
rows=[]
for p in ps:
 for rv in rs:
  v256=calc(rv,p,256);v512=calc(rv,p,512)
  rows.append(dict(p=p,r_over_a=rv,f256=v256,f512=v512,abs_diff=abs(v256-v512),sign='negative' if v512<0 else 'positive'))
 with open(P/'critical_scan.csv','w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print('p',p,'negative',sum(x['f512']<0 for x in rows if x['p']==p),flush=True)
summary={'model':'isolated spherical simple-QUMOND fixed Plummer gravity; isotropic generalized cored tracer','critical_asymptotic_p':1.5,'sample_count':len(rows),'radius_samples':rs,'p_samples':ps,'counts':{str(p):sum(x['f512']<0 for x in rows if x['p']==p) for p in ps},'caveats':['finite radius grid does not establish global positivity','the p=1.5 leading singular coefficient vanishes and subleading terms matter','quadrature convergence does not validate physical assumptions']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
