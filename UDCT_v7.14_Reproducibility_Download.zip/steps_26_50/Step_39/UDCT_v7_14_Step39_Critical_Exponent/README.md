# UDCT v7.14 — Step 39: Critical exponent audit (exploratory)

## Scope
Follow-up to Step 38. Reuses its explicit spherical *simple-QUMOND* acceleration prescription and generalized cored tracer density, but runs a new focused 81-point numerical grid. This is not a fit to individual Hydrus I velocities, not a 3D external-field calculation, and not a preregistered result.

## Model
- Fixed Plummer gravitating mass: M=32730 solar masses, a=53.3 pc; G=4.30091e-3 pc (km/s)^2 / solar mass.
- Isolated spherical simple-QUMOND acceleration: g=(g_N/2)+sqrt(g_N^2/4+a0*g_N), a0=1.2e-10 m/s^2.
- Isotropic tracer density rho=(1+(r/a)^p)^(-5/p) (normalization rho0=1).
- Potential increases outward, Psi(r)=Phi(r)-Phi(0). Energy E=Psi(r0). The inversion is the unbounded-potential Abel inversion f(E)=1/(sqrt(8)*pi^2) integral_E^infinity rho''(Psi)/sqrt(Psi-E) dPsi, with boundary assumptions implicit in the formula. The integral is transformed to log radius and regularized near the lower endpoint.

## Asymptotic prediction
At small r: g_N~r, g~r^(1/2), Psi~r^(3/2). The tracer behaves as rho~rho0-A*Psi^(2p/3). For p != 1.5, the leading singular contribution to f(E) is proportional to (1-2p/3)*E^(2p/3-3/2) with positive prefactor in the applicable asymptotic regime (p near 1.5). Thus p=1.5 is a *central asymptotic* sign boundary. At p=1.5 the leading coefficient cancels and subleading/nonlocal terms must be retained.

## Numerical verification
`python step39.py` writes `critical_scan.csv` and `results.json`. 9 p values x 9 log-spaced radii = 81 points, with 256 and 512 Gauss-Legendre nodes per point. Compare signs and numerical differences. The 81-point scan is finite; no claim of all-energy positivity for p<=1.5. The finite-r onset of negative values depends on radius; it need not coincide exactly with the asymptotic p=1.5 boundary.

## Limitations
1. Density is a tracer profile and need not be self-consistent with the fixed Plummer source.
2. Positivity of an isotropic DF is stronger than positivity of Jeans second moments but weaker than a complete dynamical stability demonstration.
3. No external field, nonsphericity, measurement uncertainties, or full Hydrus I star-by-star likelihood is included.
4. Potential interpolation and common derivatives remain shared numerical assumptions; quadrature refinement alone does not independently validate them.
5. A finite grid cannot certify global DF non-negativity.
