import numpy as np, csv, json
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from scipy.special import beta
from numpy.polynomial.legendre import leggauss
from pathlib import Path
D=Path(__file__).resolve().parent
G=4.30091e-3;a=53.3;M=32730.;a0=1.2e-10*3.085677581491367e16/1e6
C=1/(np.sqrt(8)*np.pi**2)
k=G*M/a**3; h=np.sqrt(a0*k); A=2*h/3
# g=h sqrt(r) + (k/2) r + O(r^1.5). Psi=A r^1.5 + (k/4) r^2 +...
# at p=3/2: rho=1-(10/3)*(r/a)^1.5 +...
# inversion r^1.5=Psi/A - (k/(4*A))*(Psi/A)^(4/3)+...
# rho=1 - B Psi + D Psi^(4/3), D=(10/3)/a^1.5 * (k/4)/A^(7/3)
B=(10/3)/a**1.5/A
Dcoef=B*(k/4)/A**(4/3)
# f ~ C D*(4/3)*(1/3)*Beta(1/2, 1/6)*E^(-1/6)
Kcritical=C*Dcoef*(4/9)*beta(.5,1/6)
xx=np.linspace(np.log(1e-13*a),np.log(1e10*a),200001)
rr=np.exp(xx)
def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+np.sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5; dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
phi=cumulative_trapezoid(g(rr)*rr,xx,initial=0)
F=PchipInterpolator(xx,phi)
def derivatives(r,p):
 y=(r/a)**p;rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y));Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 return rho*L,rho*(L*L+Lp)

def fcalc(rv,p,N=256):
 r0=rv*a; L=np.log(1e8*a/r0)
 z,w=leggauss(N);t=(z+1)*np.sqrt(L)/2
 r=r0*np.exp(t*t);gr=g(r);d1,d2=derivatives(r,p)
 d2phi=(d2*gr-d1*gp(r))/gr**3
 delta=F(np.log(r))-float(F(np.log(r0)))
 val=C*np.dot(w,d2phi*gr*2*t*r/np.sqrt(delta))*np.sqrt(L)/2
 return val
ps=[1.49,1.499,1.5,1.501,1.51,1.55]
radii=[1e-4,1e-5,1e-6,1e-7,1e-8]
rows=[]
for p in ps:
 for rv in radii:
  f1=fcalc(rv,p,192);f2=fcalc(rv,p,384)
  E=float(F(np.log(rv*a))-phi[0]);alpha=2*p/3
  # rho ~ 1 - (5/p) (r/a)^p = 1 - H E^alpha
  H=(5/p)*a**(-p)*A**(-alpha)
  leading=C*H*alpha*(1-alpha)*beta(.5,1.5-alpha)*E**(alpha-1.5) if alpha!=1 and alpha<1.5 else None
  special=Kcritical*E**(-1/6) if p==1.5 else None
  rows.append(dict(p=p,r_over_a=rv,E=E,f192=f1,f384=f2,relative_difference=abs(f2-f1)/max(abs(f2),1e-30),leading_asymptotic=leading,critical_subleading=special))
with (D/'audit.csv').open('w',newline='') as out:
 writer=csv.DictWriter(out,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
(D/'summary.json').write_text(json.dumps(dict(k=k,h=h,A=A,B=B,Dcoef=Dcoef,critical_coefficient=Kcritical,results=rows),indent=2,default=str))
for p in ps:
 print(p,[(r['r_over_a'],round(r['f384'],5),round(r['relative_difference'],6)) for r in rows if r['p']==p])
print('critical K',Kcritical)
