# UDCT v7.14 — Step 40: Critical-exponent asymptotic audit

Status: exploratory, NOT preregistered, not a Hydrus I star-by-star fit, not 3D EFE.

## Reproduction

`python -m pip install -r requirements.txt`
`python step40.py`

This produces `audit.csv` (30 samples) and `summary.json`. The numerical calculation reuses the **physical model and inversion equation** of Step 39 but recomputes the potential on a denser, wider grid and evaluates 192- and 384-node Gauss–Legendre integrals. Thus it is an independently rerun numerical calculation, **not an independent proof of the inversion theorem**. The small differences between node counts assess only quadrature convergence.

## Model

G=4.30091e-3 pc (km/s)^2/Msun; M=32730 Msun; a=53.3 pc; a0=1.2e-10 m/s². Plummer gravitating mass with isolated spherical simple-QUMOND acceleration

    gN(r)=GM r/(r²+a²)^(3/2)
    g(r)=gN/2 + sqrt(gN²/4+a0*gN)

Tracer density rho_p(r)=[1+(r/a)^p]^(-5/p), with rho(0)=1. Potential Psi=Phi(r)-Phi(0), E=Psi(r0), and the **unbounded-potential isotropic Abel inversion**

    f(E) = [1/(sqrt(8)*pi²)] integral_E^infinity rho''(Psi)/sqrt(Psi-E) dPsi.

The inversion assumes adequate decay at infinity and a stationary isotropic DF f(v²/2+Psi); it does not establish physical stability or uniqueness beyond these assumptions.

## New asymptotic calculation

Let k=GM/a³ and h=sqrt(a0*k). As r→0:

    g(r)=h r^(1/2)+(k/2)r+O(r^(3/2))
    Psi(r)=A r^(3/2)+(k/4)r²+O(r^(5/2)), A=2h/3.

For p near 3/2, set alpha=2p/3. Then

    rho(Psi)=1-H Psi^alpha+...,
    H=(5/p) a^(-p) A^(-alpha)>0.

For 0<alpha<3/2, alpha!=1, the contribution of this term to the inversion is

    f(E) ~ C H alpha(1-alpha) Beta(1/2,3/2-alpha) E^(alpha-3/2),
    C=1/(sqrt(8)*pi²).

This predicts positive leading central divergence for p<3/2 and negative leading central divergence for 3/2<p<9/4. The formula is **not** a universal global sign theorem, and should not be extrapolated to p>=9/4 where nonlocal or endpoint contributions may dominate.

At p=3/2, alpha=1 and the leading rho'' term vanishes. Inverting Psi(r) to next order gives

    rho(Psi)=1-B Psi+D Psi^(4/3)+...,
    B=(10/3) a^(-3/2)/A,
    D=B*(k/4)/A^(4/3)>0.

Consequently

    f(E) ~ C D*(4/9)*Beta(1/2,1/6) E^(-1/6)>0.

For the chosen parameters the predicted positive coefficient is in `summary.json`. This is a **new subleading analytic check** absent from the Step 39 leading-order claim. The p→1.5 and E→0 limits are nonuniform, so finite-radius sign transitions can occur at p>1.5 and depend on radius.

## Selected numerical results (dimensionless DF normalization)

| p | f(r/a=1e-6) | f(r/a=1e-8) |
|---|---:|---:|
| 1.499 | +0.150386 | +4.321046 |
| 1.500 | +0.015387 | +0.034702 |
| 1.501 | -0.116177 | -4.104251 |

At p=1.5, asymptotic f(E) at r/a=1e-8 is about +0.02825 vs numerical +0.03470; the asymptotic limit is not fully reached. The coefficient is not fitted to numerical results.

## Important limitations

- This calculation confirms a **local asymptotic sign mechanism**, not an all-energy positivity criterion.
- A positive central DF does not imply a globally nonnegative DF.
- The tracer profile is imposed independently of the Plummer gravitating mass; no individual stellar velocities were fitted.
- No 3D external field, flattening, velocity anisotropy, or Hessian sign-bracket rerun is included.
- Independent symbolic review and an alternative inversion formulation remain desirable.
- The 24 v7.13 candidates were not established as 24 physical sign crossings.
