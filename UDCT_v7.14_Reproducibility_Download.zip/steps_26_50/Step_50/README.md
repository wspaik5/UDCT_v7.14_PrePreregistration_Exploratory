# UDCT v7.14 Step 50 — OM negative-lobe tangency audit

Exploratory, **not preregistered**. Independent of observational stellar-velocity fitting.

For the OM augmented density, f(Q;ra)=f_iso(Q)+B(Q)/(ra/a)^2. At a zero, (ra/a)^2=-B/f_iso. A pair of zero crossings merges where this ratio reaches a local maximum with respect to log(r/a). The radius is an energy-label turning radius, not a stellar orbit radius.

The script evaluates the original Step 47 quadrature kernel, searches r/a in [0.25,0.75], and checks 96/192/384 point Gauss-Legendre quadratures. A separate scan over [0.15,0.95] tests negative-lobe widths for p=1.5. This is a **local finite-domain** result, not a proof of global DF nonnegativity or QUMOND failure.

Run: `python step50.py` (requires numpy, scipy, pandas). Outputs: `critical_tangencies.csv`, `p1p5_lobe_collapse.csv`, `summary.json`. No network needed.

The bundled `step47_reference.py` is the computational kernel copied from the previous step. The Step 50 numerical methods and tolerances are fully recorded in `step50.py`.
