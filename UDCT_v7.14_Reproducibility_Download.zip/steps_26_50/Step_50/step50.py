import sys,csv,json,zipfile,os
from pathlib import Path
import numpy as np
from scipy.optimize import minimize_scalar,brentq
sys.path.insert(0,str(Path(__file__).resolve().parent))
from step47_reference import one
D=Path(__file__).resolve().parent
ps=[1.49,1.5,1.501];rows=[];roots=[]
for p in ps:
 def terms(z,n):
  r=float(np.exp(z));iso=one(r,p,np.inf,n);half=one(r,p,.5,n);B=.25*(half-iso);return iso,B
 def critical(z,n):
  iso,B=terms(z,n)
  return float(np.sqrt(-B/iso)) if iso>0 and B<0 else 0.
 opt=minimize_scalar(lambda z:-critical(z,192),bounds=(np.log(.25),np.log(.75)),method='bounded',options={'xatol':2e-8})
 z=opt.x;r=float(np.exp(z));ra=critical(z,192);iso,B=terms(z,192)
 ra96=critical(minimize_scalar(lambda z:-critical(z,96),bounds=(np.log(.25),np.log(.75)),method='bounded',options={'xatol':2e-8}).x,96)
 ra384=critical(z,384)
 h=1e-3;deriv=( (iso if False else (lambda t: sum(terms(t,192)[i]*(1 if i==0 else 1/ra**2) for i in range(2)))(z+h)) - (lambda t: sum(terms(t,192)[i]*(1 if i==0 else 1/ra**2) for i in range(2)))(z-h))/(2*h)
 rows.append(dict(p=p,critical_ra_over_a=ra,tangent_r_over_a=r,f_at_tangent=iso+B/ra**2,df_dlogr_finite_difference=deriv,critical_ra_n96=ra96,critical_ra_at_same_r_n384=ra384,delta_ra_n384_minus_n192=ra384-ra,domain='r/a 0.25 to 0.75; local lobe only'))
 print('critical',rows[-1],flush=True)
 if p==1.5:
  for test_ra in [.4,.45,.46,.465,ra,.468,.47,.5]:
   def f(z):
    i,b=terms(z,192);return i+b/test_ra**2
   zz=np.linspace(np.log(.15),np.log(.95),23)
   cross=[]
   for aa,bb in zip(zz[:-1],zz[1:]):
    if f(aa)*f(bb)<0:cross.append(float(np.exp(brentq(f,aa,bb,xtol=1e-9))))
   mn=minimize_scalar(f,bounds=(np.log(.15),np.log(.95)),method='bounded',options={'xatol':1e-7})
   roots.append(dict(p=p,ra_over_a=test_ra,roots_r_over_a=';'.join(f'{x:.10f}' for x in cross),minimum_f=mn.fun,minimum_r_over_a=np.exp(mn.x),domain='r/a 0.15 to 0.95'))
   print('lobe',roots[-1],flush=True)
for name,data in [('critical_tangencies.csv',rows),('p1p5_lobe_collapse.csv',roots)]:
 with (D/name).open('w',newline='') as fh:
  w=csv.DictWriter(fh,fieldnames=data[0].keys());w.writeheader();w.writerows(data)
(D/'summary.json').write_text(json.dumps({'step':50,'p_values':ps,'critical_tangencies':rows,'lobe_scan':roots,'model':'isolated spherical QUMOND, Plummer gravitating mass, tracer [1+(r/a)^p]^(-5/p), OM','limitations':['Finite radius domain; other negative lobes may exist','96/192/384 quadratures share the same physical inversion','Not a full phase-space positivity proof','Not an observed Hydrus I fit']},indent=2))
(D/'README.md').write_text('''# UDCT v7.14 Step 50 — OM negative-lobe tangency audit\n\nExploratory, **not preregistered**. Independent of observational stellar-velocity fitting.\n\nFor the OM augmented density, f(Q;ra)=f_iso(Q)+B(Q)/(ra/a)^2. At a zero, (ra/a)^2=-B/f_iso. A pair of zero crossings merges where this ratio reaches a local maximum with respect to log(r/a). The radius is an energy-label turning radius, not a stellar orbit radius.\n\nThe script evaluates the original Step 47 quadrature kernel, searches r/a in [0.25,0.75], and checks 96/192/384 point Gauss-Legendre quadratures. A separate scan over [0.15,0.95] tests negative-lobe widths for p=1.5. This is a **local finite-domain** result, not a proof of global DF nonnegativity or QUMOND failure.\n\nRun: `python step50.py` (requires numpy, scipy, pandas). Outputs: `critical_tangencies.csv`, `p1p5_lobe_collapse.csv`, `summary.json`. No network needed.\n\nThe bundled `step47_reference.py` is the computational kernel copied from the previous step. The Step 50 numerical methods and tolerances are fully recorded in `step50.py`.\n''')
(D/'requirements.txt').write_text('numpy>=1.24\nscipy>=1.10\npandas>=1.5\n')
