# UDCT v7.14 — Step 38: expanded energy and central-shape audit

**Status:** exploratory, not preregistration, not an observational fit.

## Model
- Spherical isolated simple-QUMOND acceleration from Plummer baryonic mass M=32730 solar masses, a=53.3 pc, a0=1.2e-10 m/s².
- Isotropic tracer density normalized to unity at center: rho=(1+(r/a)^p)^(-5/p).
- Center-referenced energy inversion in an unbounded logarithmic asymptotic potential; the tabulated r is the energy-turning radius, not an observed star position.
- Log-radius potential integration and PCHIP interpolation; Gauss–Legendre integration with 256 and 512 nodes for a numerical comparison.

## Reproduce
`python step38.py` requires NumPy and SciPy. Regenerates `full_energy_scan.csv` and `results.json`.

## Result
13 p values times 91 log-spaced turning radii in [1e-6 a, 1e3 a]. All 91 sampled values nonnegative for p<=1.5; negative values appear at p=1.55 and higher. The observed onset is bounded by the *tested grid* (1.50, 1.55], not a proven physical critical exponent.

## Numerical limitations
The difference between 256- and 512-node estimates is a quadrature convergence check only. Both use the same interpolated potential and derivative formulas, so systematic bias is shared. For p=1 the largest absolute N-difference is ~1.96e-6; this deserves targeted refinement. Potential interpolation starts at r/a=1e-10, not r=0; finite outer radius r/a=1e9 for inversion; far-tail and center asymptotics are not proven. Sign near zero should be checked with independent adaptive integration and high precision. Positive finite samples do not prove f(E)>=0 everywhere, and positive DF does not guarantee a fully self-consistent stellar-gravity model. No EFE, 3D or Hydrus I stellar-velocity fit.

## Files
- `step38.py`: executable analysis
- `full_energy_scan.csv`: all 1,183 values, both quadratures
- `results.json`: summary
- `requirements.txt`: dependencies
