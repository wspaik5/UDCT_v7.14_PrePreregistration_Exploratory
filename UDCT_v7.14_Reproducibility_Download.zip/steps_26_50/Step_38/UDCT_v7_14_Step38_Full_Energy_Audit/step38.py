import numpy as np,csv,json
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from numpy.polynomial.legendre import leggauss
from pathlib import Path
P=Path(__file__).resolve().parent
G=4.30091e-3;a=53.3;M=32730.;a0=1.2e-10*3.085677581491367e16/1e6
C=1/(np.sqrt(8)*np.pi**2)
def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+np.sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def deriv(r,p):
 y=(r/a)**p;rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y));Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 return rho*L,rho*(L*L+Lp)
# precompute potential integral with respect to log r; independent quadrature for DF
x=np.linspace(np.log(1e-10*a),np.log(1e10*a),160001)
r=np.exp(x);phi=cumulative_trapezoid(g(r)*r,x,initial=0)
F=PchipInterpolator(x,phi)
def calc(r0,p,N=256):
 xmax=np.log(1e9*a/r0); z,w=leggauss(N);t=(z+1)*np.sqrt(xmax)/2
 rr=r0*np.exp(t*t);gr=g(rr);d1,d2=deriv(rr,p)
 d2rho=(d2*gr-d1*gp(rr))/gr**3
 delta=F(np.log(rr))-float(F(np.log(r0)))
 # t=0 never sampled; integral d2rho/dphi2 * dphi / sqrt(phi-phi0)
 integrand=d2rho*gr*2*t*rr/np.sqrt(delta)
 return C*np.dot(w,integrand)*np.sqrt(xmax)/2
ps=[1.,1.25,1.4,1.5,1.55,1.6,1.65,1.7,1.75,2.,2.5,3.,4.]
rs=np.logspace(-6,3,91)
rows=[]
for p in ps:
 for rv in rs:
  f256=calc(rv*a,p,256);f512=calc(rv*a,p,512)
  rows.append(dict(p=p,r_over_a=float(rv),f256=float(f256),f512=float(f512),abs_diff=float(abs(f512-f256)),sign='negative' if f512<0 else 'positive'))
 with open(P/'full_energy_scan.csv','w',newline='') as fh:
  wr=csv.DictWriter(fh,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)
 print(p, 'neg',sum(q['f512']<0 for q in rows if q['p']==p),flush=True)
summary={'model':'fixed Plummer gravity, isotropic generalized cored tracer, isolated simple QUMOND','sampled_r_over_a':[1e-6,1e3],'n_per_p':len(rs),'n':len(rows),'by_p':{},'caveat':'finite samples do not prove all-energy positivity; endpoint and far tail require separate analytical treatment'}
for p in ps:
 q=[row for row in rows if row['p']==p]; neg=[row for row in q if row['f512']<0]
 summary['by_p'][str(p)]={'negative_count':len(neg),'first_negative_r_over_a':neg[0]['r_over_a'] if neg else None,'last_negative_r_over_a':neg[-1]['r_over_a'] if neg else None,'max_abs_N_difference':max(row['abs_diff'] for row in q)}
(P/'results.json').write_text(json.dumps(summary,indent=2))
