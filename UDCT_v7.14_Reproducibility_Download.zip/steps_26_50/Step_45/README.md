# UDCT v7.14 — Step 45: OM Anisotropy Audit

Status: pre-preregistration exploration, 2026-10-25.

## Objective
Test whether the central negative distribution function in the isolated spherical Plummer-QUMOND field persists when the generalized cored tracer is assigned Osipkov–Merritt (OM) anisotropy.

## Model
- Gravitating Plummer source: mass M=32730 Msun, scale a=53.3 pc.
- Acceleration in spherical QUMOND: g = g_N/2 + sqrt(g_N^2/4 + a0*g_N), with a0=1.2e-10 m/s^2.
- Tracer density normalized to unity at center: rho=(1+(r/a)^p)^(-5/p).
- OM augmented tracer: rho_Q=(1+r^2/ra^2)rho.
- OM inversion of rho_Q with respect to the potential Phi(r) with Phi'(r)=g(r); the zero of Phi is arbitrary and the potential diverges logarithmically at infinity.
- Isotropic case ra=infinity.
- Formula: f(Q)=(1/(sqrt(8) pi^2)) integral_{Phi(Q)}^infty [d²rho_Q/dPhi²]/sqrt(Phi-Phi(Q)) dPhi, where Q denotes the appropriate OM energy coordinate under this convention.
- Numerically integrate in logarithmic radius with a square-root change of variables, solving potential differences with solve_ivp and integrating with scipy.quad.

## Reproduce
Python 3 with numpy and scipy:

    pip install -r requirements.txt
    python step45.py

Outputs `om_scan.csv`, `summary.csv`, and `summary.json`.

## Results
4 p values × 5 ra/a values × 6 radius-to-energy mappings = 120 computed points; 16 negative. See summary.csv for per-model counts and om_scan.csv for each value.

Notably, at p=1.501, negative points occur for ra/a=2 and infinity at r/a=1e-5, but none of the six sampled energies are negative for ra/a=0.5,0.65,1.0. At p=2, negative points occur for all five anisotropy cases, though at different energies.

## Interpretation and limitations
- The OM f(Q) and isotropic f(E) are different phase-space distribution functions; do not interpret positivity at six points as global positivity.
- This is a spherical isolated QUMOND model, not a 3D EFE simulation.
- The six samples do not establish a global sign boundary or global DF non-negativity. Finer sampling and density reconstruction from f(Q) are needed.
- No direct fit to individual Hydrus I line-of-sight velocities was performed.
- Numerical quadrature error estimates do not cover systematic model errors, physical interpretation of OM energy, or errors from truncating at 1e9 a.
- These results neither establish a failure of all MOND models nor establish priority over existing literature.
