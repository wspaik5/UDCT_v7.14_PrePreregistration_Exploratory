"""Step 45: Osipkov-Merritt inversion for generalized cored tracer in isolated spherical QUMOND.
Uses direct radial quadrature and augmented density rho_Q=(1+r^2/ra^2)rho.
The potential grows without bound; boundary derivative at infinity is zero for these tracers.
"""
import csv, json
from pathlib import Path
import numpy as np
from scipy.integrate import quad, solve_ivp
from math import sqrt,pi,log
D=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=32730.
a0=1.2e-10*3.085677581491367e16/1e6
C=1/(sqrt(8)*pi*pi)
def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*sqrt(.25*n*n+a0*n)))
def augmented_derivatives(r,p,ra_over_a):
 y=(r/a)**p
 rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y))
 Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 rho1=rho*L
 rho2=rho*(L*L+Lp)
 if np.isinf(ra_over_a):return rho1,rho2
 ra=ra_over_a*a
 h=1+(r/ra)**2
 return h*rho1+2*r*rho/(ra*ra),h*rho2+4*r*rho1/(ra*ra)+2*rho/(ra*ra)
def rho2phi(r,p,ra):
 d1,d2=augmented_derivatives(r,p,ra)
 gr=g(r)
 return (d2*gr-d1*gp(r))/gr**3
def df(p,ra,rr,outer=1e9):
 r0=rr*a
 umax=log(outer*a/r0)
 sol=solve_ivp(lambda u,v:[g(r0*np.exp(u))*r0*np.exp(u)],(0,umax),[0.],rtol=1e-10,atol=1e-11,dense_output=True)
 if not sol.success:raise RuntimeError(sol.message)
 def integrand(t):
  if t==0:return 2*rho2phi(r0,p,ra)*sqrt(g(r0)*r0)
  u=t*t;r=r0*np.exp(u); delta=float(sol.sol(u)[0])
  return 2*t*rho2phi(r,p,ra)*g(r)*r/sqrt(delta)
 val,err=quad(integrand,0,sqrt(umax),epsabs=1e-10,epsrel=3e-9,limit=250)
 return C*val,C*err

def main():
 ps=[1.49,1.5,1.501,2.0]
 ras=[0.5,0.65,1.0,2.0,float('inf')]
 rrs=[1e-5,1e-3,0.03,0.3,1.0,3.0]
 rows=[]
 for p in ps:
  for ra in ras:
   for rr in rrs:
    f,e=df(p,ra,rr)
    rows.append(dict(p=p,ra_over_a=('inf' if np.isinf(ra) else ra),r_energy_over_a=rr,df=f,quad_error=e,sign=('negative' if f<0 else 'positive' if f>0 else 'zero')))
   print('done',p,ra,flush=True)
 with (D/'om_scan.csv').open('w',newline='') as fh:
  w=csv.DictWriter(fh,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 summary=[]
 for p in ps:
  for ra in ras:
   subset=[x for x in rows if x['p']==p and x['ra_over_a']==('inf' if np.isinf(ra) else ra)]
   summary.append(dict(p=p,ra_over_a=subset[0]['ra_over_a'],negative_count=sum(x['df']<0 for x in subset),min_df=min(x['df'] for x in subset),central_df=subset[0]['df']))
 with (D/'summary.csv').open('w',newline='') as fh:
  w=csv.DictWriter(fh,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
 (D/'summary.json').write_text(json.dumps({'n_cases':len(rows),'n_negative':sum(x['df']<0 for x in rows),'model':'spherical isolated QUMOND with generalized cored tracer and OM augmented density','outer_cutoff_a':1e9,'notes':['OM f(Q) is not the same as isotropic f(E)','finite grid: no claim of positivity over all energies','no actual Hydrus I individual star velocity fit','common potential and inversion assumptions']},indent=2))
 print('negative',sum(x['df']<0 for x in rows),'/',len(rows))
if __name__=='__main__':main()
