"""UDCT v7.14 exploratory Step 37: cored/cusped tracer density sensitivity.
Spherical isolated simple-QUMOND gravity from fixed Plummer baryonic source.
Generalized tracer rho=[1+(r/b)^p]^(-5/p), normalized rho(0)=1.
Center-referenced unbounded-potential Eddington inversion (sign test).
"""
from pathlib import Path
import numpy as np, csv, json
from scipy.integrate import quad
P=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=32730.; a0=1.2e-10*3.085677581491367e16/1e6
C=1/(np.sqrt(8)*np.pi**2)
def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+np.sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def deriv(r,p,b):
 x=r/b; y=x**p; z=1+y
 rho=z**(-5/p)
 L=-5*y/(r*z)
 Lp=5*y*(1+y-p)/(r*r*z*z)
 return rho*L,rho*(L*L+Lp)
def calc(r0,p,b,outer=1e7):
 tmax=np.sqrt(np.log(outer*a/r0))
 def f(t):
  if t==0:t=1e-8
  r=r0*np.exp(t*t)
  gr=g(r); gpr=gp(r); d1,d2=deriv(r,p,b)
  d2rho=(d2*gr-d1*gpr)/gr**3
  phi=quad(lambda z:g(r0*np.exp(z))*r0*np.exp(z),0,t*t,epsrel=2e-9,epsabs=1e-12)[0]
  return d2rho*gr*2*t*r/np.sqrt(phi)
 val,err=quad(f,0,tmax,epsrel=3e-7,epsabs=1e-9,limit=220)
 return C*val,C*err
rows=[]
for p in [1.,1.25,1.5,1.75,2.,2.5,3.,4.]:
 for rv in [0.0001,0.001,0.01,0.1,0.5]:
  val,err=calc(rv*a,p,a)
  rows.append(dict(p=p,r_over_a=rv,df=val,quad_error=err,sign='negative' if val<0 else 'positive'))
  print(p,rv,round(val,8),flush=True)
with (P/'cusp_profile_scan.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
summary=dict(n_cases=len(rows),negative=sum(r['df']<0 for r in rows),positive=sum(r['df']>0 for r in rows),model='isolated spherical simple-QUMOND from Plummer baryonic source; generalized cored tracer rho=(1+(r/a)^p)^(-5/p)',cautions=['p changes inner shape and outer approach; no observed Hydrus profile fit','positive at sampled energies is not an all-energy proof','same potential as previous steps; no external field or full 3D DF','quadrature errors exclude systematic errors'])
(P/'results.json').write_text(json.dumps(summary,indent=2))
