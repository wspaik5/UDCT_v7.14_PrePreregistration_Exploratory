# UDCT v7.14 Step 37 — Central tracer-shape sensitivity (exploratory)

## Run
`python step37.py` (Python 3, NumPy, SciPy). Outputs `cusp_profile_scan.csv` and `results.json`.

## Setup
Fixed baryonic Plummer source: M=32730 Msun, a=53.3 pc, isolated spherical simple-QUMOND acceleration. Normalized stellar tracer density: rho(r)/rho(0)=[1+(r/a)^p]^(-5/p). The tracer profile is finite at r=0 for all p. Here 'central shape' is more accurate than 'cusp': p<2 has a nonanalytic center, but density does not diverge.

The distribution function is computed via a center-referenced, unbounded-potential isotropic Abel inversion. p=2 recovers Plummer tracer. This is a controlled model-family sensitivity, not a realistic profile fit.

## Findings
40 evaluations (8 p values x 5 energy turning radii). p=1,1.25,1.5 are positive at all sampled points; p>=1.75 has at least one negative sampled value. The sign at small energies depends strongly on the tracer center-shape assumption. This does not imply all-energy positivity for p<=1.5.

## Limits
No external field; no anisotropic 3D equilibrium; no full Hydrus I individual-star fit; no claim about UDCT-specific gravity or QUMOND generally. Values normalized to unit central tracer density; compare signs, not amplitudes across p.
