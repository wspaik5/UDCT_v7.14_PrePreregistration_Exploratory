"""Independent radial-variable Abel inversion, fixed physical energy.
All radii are in units of a; potential in (km/s)^2; tracer rho normalized.
"""
import csv,json
from pathlib import Path
import numpy as np
from scipy.integrate import solve_ivp,quad
from scipy.special import roots_legendre
from math import pi,sqrt,log
D=Path(__file__).resolve().parent
G=4.30091e-3;a=53.3;M=32730.
a0=1.2e-10*3.085677581491367e16/1e6
C=1/(sqrt(8)*pi*pi)
def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*sqrt(.25*n*n+a0*n)))
def rho2phi(r,p):
 y=(r/a)**p;rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y));Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 d1=rho*L;d2=rho*(L*L+Lp);gr=g(r)
 return (d2*gr-d1*gp(r))/(gr**3)
def make_solution(r0, Rmax):
 umax=log(Rmax/r0)
 sol=solve_ivp(lambda u,v:[g(r0*np.exp(u))*r0*np.exp(u)],(0,umax),[0.],rtol=2e-11,atol=1e-12,dense_output=True)
 if not sol.success:raise RuntimeError(sol.message)
 return sol
def calc(p,r0,sol,R):
 umax=log(R/r0)
 # u=t^2 removes the Abel square-root singularity
 def integrand(t):
  if t==0:
   # phi difference ~ g(r0)*r0*t^2
   return 2*rho2phi(r0,p)*g(r0)*r0/sqrt(g(r0)*r0)
  u=t*t;r=r0*np.exp(u);delta=float(sol.sol(u)[0])
  return 2*t*rho2phi(r,p)*g(r)*r/sqrt(delta)
 val,err=quad(integrand,0,sqrt(umax),epsabs=1e-11,epsrel=2e-9,limit=300)
 return C*val,C*err

def main():
 ps=[1.49,1.5,1.501,2.0];rrs=[1e-4,0.01,0.1,1.0]
 cutoffs=[1e4,1e5,1e6,1e7,1e9,1e12]
 rows=[]
 for p in ps:
  for rr in rrs:
   r0=rr*a;sol=make_solution(r0,1e14*a)
   ref,referr=calc(p,r0,sol,1e14*a)
   for cutoff in cutoffs:
    value,err=calc(p,r0,sol,cutoff*a)
    rows.append(dict(p=p,r_energy_over_a=rr,outer_over_a=cutoff,df=value,reference_df=ref,delta_to_reference=ref-value,abs_delta=abs(ref-value),quad_error_est=err,reference_quad_error_est=referr))
   print(f'p={p:.3f}, rE/a={rr:g}, f_inf≈{ref:.10g}, tail_1e4={ref-calc(p,r0,sol,1e4*a)[0]:.3e}',flush=True)
 with (D/'fixed_energy_tail.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 meta={'cases':len(rows),'reference_outer_radius_over_a':1e14,'reference_is_finite_not_proven_infinite':True,'max_abs_delta_by_cutoff':{str(c):max(z['abs_delta'] for z in rows if z['outer_over_a']==c) for c in cutoffs},'min_abs_reference_df':min(abs(z['reference_df']) for z in rows),'warnings':['Numerical tail estimate, not a rigorous mathematical bound','Same spherical QUMOND field and isotropic Abel inversion assumptions','Fixed physical energy (rE/a), unlike earlier changing-grid sample counts','Reference 1e14 a is finite; no claim of exact infinity']}
 (D/'summary.json').write_text(json.dumps(meta,indent=2))
if __name__=='__main__':main()
