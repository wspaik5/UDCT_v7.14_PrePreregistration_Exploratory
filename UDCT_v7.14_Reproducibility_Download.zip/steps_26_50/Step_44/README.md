# UDCT v7.14 — Step 44: Fixed-energy outer-tail audit

Status: exploratory, **not preregistration**, 2026-10-25.

## Scientific question
Does the negative isotropic distribution function in a specified isolated spherical Plummer–QUMOND model depend on truncating the outer radial integration?

## Model and method
Gravitating mass: spherical Plummer with a=53.3 pc, M=32730 solar masses. G=4.30091e-3 pc (km/s)^2 / Msun; a0=1.2e-10 m/s^2. Spherical acceleration g=gN/2+sqrt(gN^2/4+a0*gN). Isotropic tracer density rho=(1+(r/a)^p)^(-5/p). p in [1.49,1.5,1.501,2.0].

The isotropic inversion is
f(E)=1/(sqrt(8)*pi^2) integral_E^infty [d²rho/dPhi²] / sqrt(Phi-E) dPhi,
with the boundary derivative at infinity vanishing for the chosen tracer. E=Phi(r_E). We compute Phi(r)-Phi(r_E) by solving dPhi/d(log r)=r*g(r) using an adaptive ODE solver. The change of variables log(r/r_E)=t² removes the lower-end Abel square-root singularity. The radial integral is then evaluated using scipy.integrate.quad. No PCHIP interpolation of the potential or Gauss-Legendre quadrature from Step 43 is used.

Cutoffs R/a = 1e4,1e5,1e6,1e7,1e9,1e12; reference R/a=1e14 (finite). For each of 4 p and 4 fixed physical energies (r_E/a=1e-4,0.01,0.1,1), 6 cutoff comparisons: 96 rows.

## Findings
At r_E/a=1e-4, reference f values: p=1.49: +0.05531349112; p=1.5: +0.009280164943; p=1.501: +0.005076663140; p=2: -0.04115614022. At p=1.501, f(r_E/a=1e-5) ≈ -0.012001 and f(r_E/a=1e-6) ≈ -0.116173, demonstrating the asymptotic sign does not dictate the sign at every finite energy.

Maximum absolute differences between cutoff calculations and the finite reference were ~6.7e-11 to 1.25e-10 across the six cutoffs. The differences are not monotonic and should be regarded as being at or below the numerical accuracy floor, **not a measured mathematical tail bound**. The asymptotic integrand decays rapidly because tracer density ~r^-5 while potential ~ln r, which qualitatively explains why far-tail effects are small.

## Limitations
- Reference cutoff 1e14 a is not infinity; no rigorous analytical upper bound is established.
- The same spherical acceleration, tracer density and isotropic inversion assumptions are shared with previous stages. This is an independent *numerical representation*, not an independent physical model.
- Numerical error estimates from quadrature do not cover every systematic error.
- This is not a direct fit to Hydrus I stellar velocities and not a 3D EFE or full Jeans/Hessian audit.
- p=1.5 is a **central asymptotic threshold** within the chosen tracer family, not a global positivity theorem.

## Reproduce
`python -m pip install -r requirements.txt` then `python step44.py`. Outputs `fixed_energy_tail.csv` and `summary.json`.
