# UDCT v7.14 Step 26 — 3D Force / Spherical Jeans Bridge

PRE-PREREGISTRATION EXPLORATORY; no new theory claim.

Run `python step26.py` (numpy, scipy). `step24_reference.py` is copied unchanged from Step 25's reference implementation. The code compares two new 3D finite-box QUMOND solutions (65^3, 97^3, 640 pc cube, zero external field, zero Dirichlet boundary) with the isolated spherical QUMOND analytic acceleration at Plummer scale a=53.3 pc. The finite-box boundary is **not** certified as isolated.

It separately integrates the spherical isotropic Jeans equation for a Plummer tracer with Newtonian stellar-only and isolated spherical QUMOND acceleration. Newtonian analytic radial sigma_r^2(a)=GM/(6 sqrt(2) a) provides a check. Radial dispersion is **not** projected LOS dispersion. The spherical Jeans integration does not incorporate the 3D computed acceleration directly; the 3D force calculation is a local cross-check only. This is not a 3D Jeans solution and not an observed-star fit.

`jeans_tail_convergence.csv` varies outer radius 1–30 kpc and integration spacing 1 to 0.5 pc. Values near the cutoff are artificial zero-boundary values. `3d_force_crosscheck.csv` compares acceleration and reports Hessian eigenvalues, which must NOT be conflated with negative velocity dispersion. `results.json` preserves constants, output, limitations.

Known limitations: spherical isotropy beta=0; no EFE; no selection-function model; no membership likelihood; no Hydrus I direct velocity fitting; no B01-B24 replay. Next: test physically admissible Jeans dispersion under anisotropy and independently validate open-boundary 3D EFE, then recover original v7.13 24 candidate definitions.
