"""Step24: non-axis-aligned EFE rotation covariance; finite cube approximate boundaries.
Runs finite-difference QUMOND source + DST Poisson; rotation interpolation diagnostics.
"""
import numpy as np, csv,json,time
from pathlib import Path
from scipy.fft import dstn,idstn
from scipy.ndimage import map_coordinates
P=Path(__file__).resolve().parent
G=4.30091e-3; A0=1.2e-10*3.085677581491367e13/1e6
A=53.3; M=5*10**((4.83+4.71)/2.5)
def nu(y):return .5*(1+np.sqrt(1+4/np.maximum(y,1e-25)))
def K0(y):
 q=np.sqrt(1+4/y);return -2/(y*q*(1+q))
def solve(n,box,ext,theta,bc):
 dx=box/(n-1); u=(np.arange(n)-(n-1)/2)*dx
 coords=np.broadcast_arrays(u[:,None,None],u[None,:,None],u[None,None,:]);r2=sum(q*q for q in coords)
 direction=np.array([np.cos(theta),np.sin(theta),0.]); gn=[-G*M*q/(r2+A*A)**1.5 for q in coords]
 v0=[gn[i]+ext*A0*direction[i] for i in range(3)]
 mag=np.sqrt(sum(q*q for q in v0));f=nu(mag/A0)
 rhs=-sum(np.gradient(f*v0[i],dx,axis=i,edge_order=2) for i in range(3))
 phi=np.zeros((n,n,n),dtype=float)
 if bc=='asymptotic':
  ne=nu(ext);ke=K0(ext)
  for j in range(3):
   for k in (0,-1):
    co=[q.take(k,axis=j) for q in coords]
    rr=np.sqrt(sum(q*q for q in co));parallel=sum(direction[i]*co[i] for i in range(3))
    sin2=1-(parallel/rr)**2
    sl=[slice(None)]*3;sl[j]=k
    phi[tuple(sl)]=-G*M*ne/rr*(1+.5*ke*sin2)
 elif bc!='zero':raise ValueError(bc)
 b=rhs[1:-1,1:-1,1:-1].copy()
 for j in range(3):
  for k,inside in ((0,0),(-1,-1)):
   sl=[slice(None)]*3;sl[j]=inside
   face=[slice(1,-1)]*3;face[j]=k
   b[tuple(sl)]-=phi[tuple(face)]/dx**2
 eig=(2*np.cos(np.pi*np.arange(1,n-1)/(n-1))-2)/dx**2
 den=eig[:,None,None]+eig[None,:,None]+eig[None,None,:]
 phi[1:-1,1:-1,1:-1]=idstn(dstn(b,type=1,norm='ortho')/den,type=1,norm='ortho')
 grad=np.gradient(phi,dx,edge_order=2)
 H=[[np.gradient(grad[i],dx,axis=j,edge_order=2) for j in range(3)] for i in range(3)]
 def probe(pos):
  ind=((np.array(pos)-u[0])/dx)[:,None]
  acc=-np.array([map_coordinates(g,ind,order=1,mode='nearest')[0] for g in grad])
  h=np.array([[map_coordinates(H[i][j],ind,order=1,mode='nearest')[0] for j in range(3)] for i in range(3)])
  return acc,(h+h.T)/2
 # sample fixed radius at 0,45,90,135,180,225,270,315 degrees
 ps=[]
 for a in np.arange(0,360,45):
  p=A*np.array([np.cos(np.deg2rad(a)),np.sin(np.deg2rad(a)),0.])
  acc,h=probe(p)
  ps.append({'angle_deg':int(a),'acc':acc.tolist(),'H':h.tolist(),'eig':np.linalg.eigvalsh(h).tolist()})
 return {'n':n,'box_pc':box,'dx_pc':dx,'ext_a0':ext,'theta_deg':float(np.rad2deg(theta)),'bc':bc,'probes':ps}
def main():
 t0=time.time();runs=[];rows=[]
 for n in (65,97):
  for bc in ('zero','asymptotic'):
   for deg in (0,45,90):
    print('RUN',n,bc,deg,flush=True)
    runs.append(solve(n,640,.1,np.deg2rad(deg),bc))
   base=next(r for r in runs if r['n']==n and r['bc']==bc and r['theta_deg']==0.)
   for deg in (45,90):
    other=next(r for r in runs if r['n']==n and r['bc']==bc and abs(r['theta_deg']-deg)<1e-8)
    rad=np.deg2rad(deg);R=np.array([[np.cos(rad),-np.sin(rad),0],[np.sin(rad),np.cos(rad),0],[0,0,1]])
    ad=[];hd=[];ed=[];ascl=[];hscl=[]
    for p in base['probes']:
     target=(p['angle_deg']+deg)%360
     q=next(x for x in other['probes'] if x['angle_deg']==target)
     a=R@np.array(p['acc']);h=R@np.array(p['H'])@R.T
     ad.append(float(np.linalg.norm(a-np.array(q['acc']))))
     hd.append(float(np.linalg.norm(h-np.array(q['H']),ord='fro')))
     ed.append(float(np.max(np.abs(np.linalg.eigvalsh(h)-np.array(q['eig'])))))
     ascl.append(float(np.linalg.norm(a)));hscl.append(float(np.linalg.norm(h,ord='fro')))
    rows.append({'n':n,'bc':bc,'rotation_deg':deg,'dx_pc':640/(n-1),'max_acc_abs':max(ad),'max_acc_relative':max(ad)/max(ascl),'max_H_fro_abs':max(hd),'max_H_relative':max(hd)/max(hscl),'max_eigen_abs':max(ed)})
    print(rows[-1],flush=True)
 with (P/'rotation_errors.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 (P/'results.json').write_text(json.dumps({'scope':'finite-box exploratory covariance under 45/90 degree rotations; not isolated EFE validation','model':'Plummer stellar mass, simple nu, Newtonian ext 0.1 a0, DST Dirichlet','runtime_seconds':time.time()-t0,'rows':rows,'runs':runs},indent=2))
if __name__=='__main__':main()
