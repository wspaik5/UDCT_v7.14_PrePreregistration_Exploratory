"""Pre-preregistration: Jeans integral and 3D force cross-check. No observational fit."""
import numpy as np, json, csv, hashlib
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
from step24_reference import solve,G,A,A0,M,nu
P=Path(__file__).resolve().parent
# Radial isotropic Jeans: sigma_r^2(r) = int_r^inf rho(s) g(s) ds / rho(r)
# Plummer tracer; finite upper limit checked explicitly.
def calc(rmax,step):
 r=np.arange(0,rmax+step/2,step)
 rho=(1+(r/A)**2)**(-2.5)
 gn=G*M*r/(r*r+A*A)**1.5
 gm=nu(np.maximum(gn/A0,1e-25))*gn
 out={}
 for key,g in [('newton',gn),('qmond_isolated',gm)]:
  f=rho*g
  integ=-cumulative_trapezoid(f[::-1],r[::-1],initial=0)[::-1]
  # negative sign is wrong for reversed integration: cumulative integral of decreasing x is negative, negate it
  sig2=integ/rho
  out[key]=np.interp([0,A,2*A,5*A],r,sig2).tolist()
 return out
rows=[]
for lim in (1000,3000,10000,30000):
 for dr in (1.,.5):
  d=calc(lim,dr)
  rows.append(dict(rmax_pc=lim,dr_pc=dr,newton_sig2_at_a=d['newton'][1],qmond_sig2_at_a=d['qmond_isolated'][1],qmond_sig2_center=d['qmond_isolated'][0],min_newton_sig2=min(d['newton']),min_qmond_sig2=min(d['qmond_isolated'])))
# Exact Newtonian Plummer isotropic radial dispersion GM/(6 sqrt(r^2+a^2))
analytic=G*M/(6*np.sqrt(2)*A)
# Direct 3D finite cube without external field, compare x-axis force to isolated spherical analytic
runs=[]
for n in (65,97):
 print('running 3D grid',n,flush=True)
 result=solve(n,640,0,0,'zero')
 p=next(p for p in result['probes'] if p['angle_deg']==0)
 acc=-p['acc'][0]
 gn=G*M*A/(2*A*A)**1.5
 target=nu(gn/A0)*gn
 runs.append(dict(n=n,dx_pc=640/(n-1),g3d=acc,g_analytic=target,relative_error=(acc-target)/target,hessian_eigenvalues=p['eig']))
with (P/'jeans_tail_convergence.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
with (P/'3d_force_crosscheck.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['n','dx_pc','g3d','g_analytic','relative_error','hessian_eigenvalues']);w.writeheader();w.writerows(runs)
summary={'status':'EXPLORATORY; no preregistration, no observed-star likelihood', 'constants':{'G':G,'a_pc':A,'a0_in_(km/s)^2_per_pc':A0,'stellar_mass_Msun':M},'newtonian_radial_sigma2_analytic_at_a':analytic,'tail_convergence':rows,'3d_force_crosscheck':runs,'cautions':['3D finite-box Dirichlet solver is NOT an isolated-boundary certified solution','Jeans integral is spherical isotropic beta=0 only; EFE 3D anisotropy not represented','No observational fitting and no v7.13 B01-B24 replay','Hessian eigenvalue signs are not signs of velocity dispersion','Finite integration upper radius gives zero at cutoff and must not be interpreted as physical boundary','Direct 3D force sample at r=a is a local check, not a full 3D Jeans solver']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps({'analytic_newton_sig2_at_a':analytic,'tail_last':rows[-1],'3d':runs},indent=2))
