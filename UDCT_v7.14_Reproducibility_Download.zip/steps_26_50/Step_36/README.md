# UDCT v7.14 Step 36 — tracer-scale sensitivity (exploratory)

Run: `python step36.py` (requires numpy and scipy). Output: tracer_scale_scan.csv and results.json.

Fixed baryonic Plummer mass M=32730 Msun and scale a=53.3 pc; isotropic Plummer tracer scale b/a = 0.5,0.75,1,1.5,2. The tracer is normalized to unit central density, so reported DF amplitudes are dimensionless-normalized and only sign comparisons are intended. Center-referenced potential, isolated spherical simple-QUMOND g = (gN+sqrt(gN^2+4 a0 gN))/2. Integration uses r=r0 exp(t²) and direct potential quadrature. All 25 tests are exploratory, not preregistered.

The sampled central energies yield negative DF for all tracer scales, but there is no all-energy proof, no external field, no 3D equilibrium, no individual-star Hydrus I fit, and no UDCT-specific physics. A negative isotropic DF for this specified tracer/potential pair does not falsify QUMOND generally. Step 35 and earlier data are not embedded; this script is self-contained.
