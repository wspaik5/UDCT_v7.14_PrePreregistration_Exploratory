"""Step 36: independent tracer-scale sensitivity, isolated spherical QUMOND.
Physical scope: fixed Plummer baryonic gravity; Plummer tracer with variable scale.
DF via isotropic Abel inversion in a center-referenced unbounded potential.
"""
import numpy as np, csv, json
from scipy.integrate import quad
from pathlib import Path
P=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=5*6546.; a0=1.2e-10*3.085677581491367e16/1e6
K=1/(np.sqrt(8)*np.pi**2)
def gravity(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+np.sqrt(.25*n*n+a0*n)
def dgravity(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def density_derivs(r,b):
 x=r/b;s=1+x*x
 return -5*x*s**(-3.5)/b,(-5*s**(-3.5)+35*x*x*s**(-4.5))/b**2
def df(r0,b,outer=1e7):
 # t = sqrt(log(r/r0)); regularizes lower square-root endpoint.
 tmax=np.sqrt(np.log(outer*a/r0))
 def integrand(t):
  if t==0:t=1e-7
  r=r0*np.exp(t*t); gg=gravity(r); gp=dgravity(r)
  rp,rpp=density_derivs(r,b)
  d2=(rpp*gg-rp*gp)/gg**3
  potential=quad(lambda z: gravity(r0*np.exp(z))*r0*np.exp(z),0,t*t,epsrel=1e-9,epsabs=1e-11)[0]
  return d2*gg*(2*t*r)/np.sqrt(potential)
 return K*quad(integrand,0,tmax,epsrel=2e-7,epsabs=1e-9,limit=200)[0]
rows=[]
for ratio in [.5,.75,1.,1.5,2.]:
 for rv in [.001,.01,.05,.1,.5]:
  r0=rv*a; v=df(r0,ratio*a)
  rows.append({'tracer_scale_over_mass_scale':ratio,'radius_over_mass_scale':rv,'df_normalized':v,'sign':'negative' if v<0 else 'positive'})
  print(ratio,rv,v,flush=True)
with (P/'tracer_scale_scan.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
# leading local coefficient: rho_tracer ~ 1-(5/2)(r/b)^2, g~r^.5 -> d2rho/dPhi^2 negative as r->0 for any finite b.
summary={'cases':len(rows),'negative':int(sum(r['df_normalized']<0 for r in rows)),'positive':int(sum(r['df_normalized']>0 for r in rows)),'model':'fixed Plummer baryonic mass, independent Plummer tracer scale; isotropic, isolated spherical simple QUMOND','parameters':{'mass_Msun':M,'mass_scale_pc':a,'a0_kms2_per_pc':a0},'note':'DF is normalized by central tracer density; signs only; no real Hydrus I stellar fit','limitations':['Only 25 sampled energies, not an all-energy proof','Only Plummer tracer family, no external field or 3D anisotropic equilibrium','Independent tracer scale is a model sensitivity, not an observed profile fit','Numerical quadrature tolerance does not bound physical systematic errors']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
