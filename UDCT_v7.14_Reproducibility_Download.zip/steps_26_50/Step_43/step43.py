"""Step 43: finite outer cutoff sensitivity, using the Step 42 inversion unchanged."""
import csv,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from step42 import run
D=Path(__file__).resolve().parent
ps=[1.49,1.5,1.501,2.0]
cutoffs=[1e4,1e5,1e6,1e7]
rows=[]
for p in ps:
 for cutoff in cutoffs:
  rec,meta=run(p,rmax=cutoff,ngrid=1000,nq=128)
  for item in rec:
   rows.append({'p':p,'cutoff_over_a':cutoff,'r_over_a':item['r_over_a'],'rho_true':item['rho_true'],'rho_reconstructed':item['rho_reconstructed'],'relative_error':item['relative_error'],'negative_samples':meta['negative_samples'],'positive_samples':meta['positive_samples'],'f_min':meta['f_min']})
  print('p',p,'cutoff',cutoff,'max_error',max(abs(z['relative_error']) for z in rec),'negative',meta['negative_samples'],flush=True)
with (D/'cutoff_scan.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary=[]
for p in ps:
 for cutoff in cutoffs:
  sel=[x for x in rows if x['p']==p and x['cutoff_over_a']==cutoff]
  summary.append({'p':p,'cutoff_over_a':cutoff,'max_abs_relative_density_error':max(abs(x['relative_error']) for x in sel),'negative_grid_samples':sel[0]['negative_samples'],'minimum_df':sel[0]['f_min']})
(D/'summary.json').write_text(json.dumps({'cases':summary,'warnings':['Grid sample counts are not phase-space volume fractions and grids change with cutoff.','This tests cutoff sensitivity, not a rigorous infinite-tail bound.','Shared inversion equation, derivative expressions and interpolation may retain common systematic errors.','The 1e7 cutoff is a numerical truncation of a logarithmically unbounded potential.']},indent=2))
