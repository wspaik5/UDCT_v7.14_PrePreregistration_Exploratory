# UDCT v7.14 — Step 43: Outer cutoff sensitivity audit

Status: pre-preregistration exploratory computation. 2026-10-25.

## Scope

Reuses the Step 42 inversion implementation **unchanged** and varies the maximum integration radius. Four tracer density exponents p = 1.49, 1.5, 1.501, 2.0; four outer cutoff radii R/a = 1e4, 1e5, 1e6, 1e7; 1000 log-spaced radial grid points and 128 Gauss-Legendre nodes. Eight reconstruction radii per case, 128 reconstruction comparisons in total.

Potential and density assumptions: fixed spherical Plummer baryonic gravitational source with a=53.3 pc, M=32730 Msun, G=4.30091e-3 pc (km/s)^2/Msun; spherical QUMOND algebraic acceleration g = gN/2 + sqrt(gN^2/4 + a0*gN), a0=1.2e-10 m/s^2; isotropic tracer rho=(1+(r/a)^p)^(-5/p).

## Run

From the extracted archive directory, run:

    python -m pip install -r requirements.txt
    python step43.py

`step43.py` imports `step42.py`, included here as a frozen dependency. Outputs `cutoff_scan.csv` and `summary.json`.

## Results

At R/a=1e4, 1e5, 1e6, 1e7 respectively, negative grid sample counts:
- p=1.49: 0,0,0,0
- p=1.5: 0,0,0,0
- p=1.501: 434,406,382,360
- p=2.0: 678,636,598,565

Max absolute relative density reconstruction errors across the 8 radii for each cutoff are approximately 0.0336%, 0.0272%, 0.0434%, 0.0497%. Results depend slightly on p.

## Important limitations

1. This is **not a rigorous bound** on the omitted infinite-radius integral. A bound requires asymptotic tail analysis or a controlled variable substitution to infinity.
2. The number of negative samples cannot be compared as a phase-space fraction because the energy grid changes with cutoff.
3. The test reuses the same inversion formula, gravitational field and derivatives as Step 42, and thus cannot detect their shared systematic errors.
4. A small density reconstruction residual is not sufficient for physical admissibility; a nonnegative distribution function is separately required.
5. The density model is parametric and has not been fit to individual Hydrus I stellar line-of-sight velocities. This is not a 3D EFE calculation.
6. The observed local asymptotic sign threshold is not yet a demonstrated global physical admissibility threshold.

## Suggested Step 44

Derive a rigorous tail bound or map the infinite radial interval to a finite integration domain and cross-check at fixed physical energy; repeat an independently derived inversion including all boundary terms.
