"""Step 34: independent local central OM asymptotic coefficient and numerical check.
Run: python step34.py (requires numpy scipy). Numerical inversion imports archived Step30 core.
"""
import numpy as np, csv, json
from scipy.special import beta
from pathlib import Path
P=Path(__file__).resolve().parent
src=P/'step30_reference.py'; ns={'__file__':str(src)}
exec(compile(src.read_text().split('qs=[.5,')[0],str(src),'exec'),ns)
a,A,a0,phi,df=(ns[k] for k in ('a','A','a0','phi','df'))
K=(2/3)*np.sqrt(a0*A/a**3)
# rho_aug/rho0 = 1 + (q^-2-5/2) (r/a)^2 + O(r^4)
# phi=K*r^3/2; coefficient D=(q^-2-5/2)/(a²*K^(4/3))
# f(E)~ [4D/(9 sqrt(8) pi²)] B(1/2,1/6) E^(-1/6)
pref=4*beta(.5,1/6)/(9*np.sqrt(8)*np.pi**2*a*a*K**(4/3))
qs=[.5,.6,np.sqrt(2/5),.65,.7,.75,1.,2.,np.inf]
rv=[1e-5,3e-5,1e-4,3e-4,1e-3,3e-3]
rows=[]
for q in qs:
 D=(0 if np.isinf(q) else 1/q**2)-2.5
 for rratio in rv:
  E=float(phi(np.log(a*rratio))); f=float(df(E,q))
  asym=float(pref*D*E**(-1/6))
  rows.append(dict(q='isotropic' if np.isinf(q) else float(q),r_over_a=rratio,E_kms2=E,numerical_f=f,asymptotic_f=asym,ratio=f/asym if abs(asym)>1e-12 else None,sign_agreement=bool(np.sign(f)==np.sign(asym)) if abs(D)>1e-8 else None))
 print('q',q,'D',D,'f at r/a=1e-5',rows[-len(rv)]['numerical_f'],'asym',rows[-len(rv)]['asymptotic_f'],flush=True)
with (P/'central_om_comparison.csv').open('w',newline='') as fh:
 w=csv.DictWriter(fh,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
summary={'model':'isolated spherical simple-QUMOND with Plummer stellar tracer and source','units':'pc, km/s, Msun; normalized tracer density','central_exponent':'f(E) proportional to E^(-1/6)','critical_q':float(np.sqrt(2/5)),'leading_coefficient_prefactor':float(pref),'number_of_numerical_checks':len(rows),'checks':rows,'limitations':['At q=sqrt(2/5) leading term cancels; higher-order expansion required','Finite r/a and numerical interpolator; ratios need not be unity at sampled radii','Necessary local sign test only; q below threshold not guaranteed globally positive','No 3D external field or observed-star likelihood','The Step30 numerical inversion is reused for comparison, so not a fully independent second numerical solver']}
(P/'results.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
