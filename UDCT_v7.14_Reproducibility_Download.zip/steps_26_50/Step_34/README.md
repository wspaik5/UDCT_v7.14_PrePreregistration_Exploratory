# UDCT v7.14 exploratory Step 34 — central OM DF sign audit

This is **pre-preregistration exploratory work**, not a UDCT validation or a direct fit to Hydrus I stars.

## Model
Isolated spherical Plummer stellar mass and tracer, M=32730 Msun, a=53.3 pc; simple-QUMOND acceleration `g = gN/2 + sqrt(gN²/4 + a0*gN)`, a0=1.2e-10 m/s². OM augmented density `rho_aug=(1+r²/ra²) rho_Plummer`. Potential defined with Phi(0)=0 and diverges logarithmically at infinity. Numerical inversion core is the archived Step30 code, copied unchanged.

## Local derivation
As r->0, g ~ sqrt(a0 GM/a³) r^(1/2), so Phi ~ K r^(3/2), K=(2/3)sqrt(a0 GM/a³). Normalize rho0=1. With q=ra/a, rho_aug=1+(q^-2-5/2)(r/a)²+O(r^4). Thus rho_aug(Phi)=1+D Phi^(4/3)+... where D=(q^-2-5/2)/(a² K^(4/3)). The unbounded-potential Abel inversion yields f(Q)~ [4 Beta(1/2,1/6)/(9 sqrt(8) pi²)] D Q^(-1/6). The sign of the leading central term flips at q=sqrt(2/5). At equality the leading term vanishes and higher-order terms are necessary.

## Run
`pip install -r requirements.txt`
`python step34.py`

Outputs: `central_om_comparison.csv`, `results.json`.

## Interpretation and limits
* 54 direct numerical comparisons across 9 anisotropy choices and 6 inner radii.
* Numerical comparison uses the same Step30 inversion implementation: analytic local derivation is independent, but there is **not** a second independent numerical inversion algorithm.
* Positive central leading coefficient does NOT establish global DF positivity. The critical q is a local asymptotic threshold, not a full physical-admissibility boundary.
* At the threshold q=sqrt(2/5), the finite-radius numerical result can be negative while the leading asymptotic term vanishes.
* Finite radii show sizable subleading corrections; numerical precision and inversion convention require continued audit.
* No external field, 3D Jeans solution, v7.13 24-case rerun, or observational likelihood test.
