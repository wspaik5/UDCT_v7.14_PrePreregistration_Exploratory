"""UDCT v7.14 Step27 exploratory spherical Jeans anisotropy audit. No 3D Jeans / observed-star fit."""
import numpy as np, json, csv
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
P=Path(__file__).resolve().parent
G=4.30091e-3; A=53.3; A0=1.2e-10*3.085677581491367e13/1e6
M=5*10**((4.83+4.71)/2.5)
def nu(y): return .5*(1+np.sqrt(1+4/np.maximum(y,1e-25)))
def run(rmax,dr,gravity,model,param):
 r=np.arange(0,rmax+dr*.1,dr)
 rho=(1+(r/A)**2)**(-2.5)
 gn=G*M*r/(r*r+A*A)**1.5
 g=gn if gravity=='Newtonian' else nu(gn/A0)*gn
 if model=='constant_beta':
  # f(r)=r^(2 beta); avoid r=0 singular for beta<0, report only r>=a/2
  f=np.maximum(r,1e-12)**(2*param)
  beta=np.full_like(r,param)
 else:
  ra=param*A
  f=r*r+ra*ra
  beta=r*r/f
 integrand=rho*f*g
 tail=-cumulative_trapezoid(integrand[::-1],r[::-1],initial=0)[::-1]
 sig2=tail/(rho*f)
 # Constant-beta Plummer DF admissibility not asserted. Jeans positivity is necessary, not sufficient.
 radii=np.array([A/2,A,2*A,5*A]); vals=np.interp(radii,r,sig2)
 return dict(gravity=gravity,anisotropy=model,parameter=param,rmax_pc=rmax,dr_pc=dr,**{f'sigma2_at_{k}a':float(v) for k,v in zip(['0p5','1','2','5'],vals)},minimum_sigma2_sampled=float(np.min(vals)),beta_at_a=float(np.interp(A,r,beta)))
rows=[]
for gravity in ('Newtonian','QUMOND_isolated'):
 for beta in (-0.5,0.,0.25,0.5):
  for rmax in (3000,10000,30000):rows.append(run(rmax,.5,gravity,'constant_beta',beta))
 for ra in (0.5,1.,2.,5.):
  for rmax in (3000,10000,30000):rows.append(run(rmax,.5,gravity,'Osipkov_Merritt_ra_over_a',ra))
with (P/'jeans_anisotropy_grid.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
newt_iso=next(x for x in rows if x['gravity']=='Newtonian' and x['anisotropy']=='constant_beta' and x['parameter']==0 and x['rmax_pc']==30000)
analytic=G*M/(6*np.sqrt(2)*A)
summary={'scope':'Spherical Plummer tracer; Newtonian and isolated spherical QUMOND analytic radial force; exploratory anisotropic Jeans integration','constants':{'G':G,'a_pc':A,'a0_km2_s2_pc':A0,'stellar_mass_Msun':M},'runs':len(rows),'newton_isotropic_at_a':newt_iso['sigma2_at_1a'],'newton_isotropic_analytic_at_a':analytic,'newton_isotropic_relative_error':newt_iso['sigma2_at_1a']/analytic-1,'all_sampled_sigma2_positive':all(row['minimum_sigma2_sampled']>0 for row in rows),'cautions':['Not a direct 3D Jeans solution: spherical radial-force input only','No external-field effect and no Hydrus I individual-star LOS fit','Jeans sigma2 positivity does not prove a nonnegative phase-space distribution function','Constant beta=0.5 can violate central cusp-anisotropy consistency for cored Plummer; do not call physically admissible','Osipkov-Merritt choices also require DF consistency tests','At the finite integration upper bound the boundary value is imposed; only report r<=5a','Not a rerun of v7.13 B01-B24']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
for x in rows:
 if x['rmax_pc']==30000:print(x['gravity'],x['anisotropy'],x['parameter'],round(x['sigma2_at_1a'],6))
