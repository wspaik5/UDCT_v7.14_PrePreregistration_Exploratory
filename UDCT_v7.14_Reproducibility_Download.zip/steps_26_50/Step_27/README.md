# UDCT v7.14 — Step 27: Spherical Jeans anisotropy audit

**Status: pre-preregistration exploratory. Not an observational validation or 3D Jeans solution.**

Run: `python step27.py` (requires numpy and scipy). Reproduces `jeans_anisotropy_grid.csv` and `results.json`.

48 numerical integrations: Newtonian vs isolated spherical QUMOND, constant beta -0.5, 0, 0.25, 0.5 and Osipkov–Merritt r_a/a 0.5, 1, 2, 5; outer integration limits 3000, 10000, 30000 pc. Grid spacing 0.5 pc. Radial sigma^2 is reported only at 0.5a, a, 2a, 5a (a=53.3 pc). Newtonian beta=0 analytic control at r=a gives GM/(6 sqrt(2) a).

Important: Plummer has a core. Constant beta > 0 is not automatically a physically consistent distribution function; central cusp-anisotropy constraints must be tested. Osipkov–Merritt models also need distribution-function positivity checks. Positivity of Jeans sigma^2 alone is necessary but insufficient. No line-of-sight projection, actual individual Hydrus I star likelihood, external field, 3D force integration, or v7.13 B01–B24 replay is included. Previous Step26 is a distinct 3D force cross-check; this step is a spherical Jeans anisotropy extension.
