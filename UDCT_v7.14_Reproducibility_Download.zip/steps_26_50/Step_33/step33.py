"""Independent central asymptotic sign audit for isolated spherical simple-QUMOND Plummer.
Compares an analytic Abel-kernel asymptotic with a numerical inversion extracted
from the archived Step 30 reference. This is a *model-specific* mathematical test.
"""
import numpy as np, json, csv, pathlib
from scipy.special import beta
P=pathlib.Path(__file__).resolve().parent
src=P/'step30_reference.py'
ns={'__file__':str(src)}
exec(compile(src.read_text().split('qs=[.5,')[0],str(src),'exec'),ns)
a=ns['a']; A=ns['A']; a0=ns['a0']; phi=ns['phi']; df=ns['df']
# At r -> 0, g_N = A r/a^3; simple QUMOND g ~ sqrt(a0*A/a^3)*sqrt(r).
# Phi ~ K r^(3/2), K=2/3 sqrt(a0*A/a^3).
# rho/rho0 = 1 - (5/2)(r/a)^2 + ... = 1 - B Phi^(4/3) + ...
# rho''(Phi) ~ -(4/9) B Phi^(-2/3).
# f(E) ~ -[4 B/(9 sqrt(8) pi²)] Beta(1/2,1/6) E^(-1/6).
K=(2/3)*np.sqrt(a0*A/a**3)
B=2.5/(a*a*K**(4/3))
coef=-(4/9)*B*beta(.5,1/6)/(np.sqrt(8)*np.pi**2)
rows=[]
for rv in [.0002,.0004,.0008,.0016,.0032,.0064,.0128,.0256,.0512]:
    r=a*rv; E=float(phi(np.log(r)))
    actual=float(df(E,np.inf)); predicted=float(coef*E**(-1/6))
    rows.append({'r_over_a':rv,'E_kms2':E,'numerical_f':actual,'asymptotic_f':predicted,'ratio_numeric_to_asymptotic':actual/predicted,'sign_agrees':bool(actual*predicted>0)})
    print(f'r/a={rv:.4g} E={E:.6g} numerical={actual:.8g} asymptotic={predicted:.8g} ratio={actual/predicted:.4g}',flush=True)
with (P/'central_sign_check.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
result={'model':'isolated spherical simple-QUMOND; Plummer self-consistent stellar tracer; no external field','analytic_derivation':{'g_small_r':'sqrt(a0 G M/a^3) r^(1/2)','Phi_small_r':'K r^(3/2)','rho_small_Phi':'rho0 [1 - B Phi^(4/3)]','d2rho_dPhi2':'-(4/9) B Phi^(-2/3)','df_small_E':'-(4 B/(9 sqrt(8) pi^2)) Beta(1/2,1/6) E^(-1/6)','K':K,'B':B,'leading_coefficient':coef},'rows':rows,'caveats':['Leading asymptotic valid only sufficiently close to center; finite-radius results contain subleading terms','Independent analytic sign argument, but numerical check reuses Step30 inversion implementation','No external field, no 3D Jeans equilibrium, no direct observational fit','Negative DF applies to this prescribed isotropic Plummer equilibrium, not to QUMOND generically']}
(P/'results.json').write_text(json.dumps(result,indent=2))
