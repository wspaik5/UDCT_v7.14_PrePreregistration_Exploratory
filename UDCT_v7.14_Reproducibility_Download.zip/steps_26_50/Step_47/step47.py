"""Step 47: exact affine OM decomposition and zero contour, grounded in Step 46 CSV."""
from pathlib import Path
import numpy as np, pandas as pd
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
from numpy.polynomial.legendre import leggauss
from math import sqrt,pi
D=Path(__file__).resolve().parent
SOURCE=D/'step46_om_2d_scan_input.csv'
if not SOURCE.exists(): SOURCE=D.parent/'UDCT_v7_14_Step46_OM_Sign_Map'/'om_2d_scan.csv'
G=4.30091e-3;a=53.3;M=32730.;a0=1.2e-10*3.085677581491367e16/1e6
C=1/(sqrt(8)*pi*pi)
def gravity(r):
 n=G*M*r/(r*r+a*a)**1.5
 dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 g=.5*n+np.sqrt(.25*n*n+a0*n)
 gp=dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
 return g,gp
def rho2phi(r,p,ra):
 y=(r/a)**p;rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y));Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 d1=rho*L;d2=rho*(L*L+Lp)
 if np.isfinite(ra):
  inv=1/(ra*a)**2;h=1+r*r*inv
  d1,d2=h*d1+2*r*rho*inv,h*d2+4*r*d1*inv+2*rho*inv
 g,gp=gravity(r)
 return (d2*g-d1*gp)/g**3
def one(rr,p,ra,n=192,outer=1e9):
 r0=rr*a;umax=np.log(outer/rr)
 sol=solve_ivp(lambda u,v:[gravity(r0*np.exp(u))[0]*r0*np.exp(u)],(0,umax),[0.],rtol=1e-10,atol=1e-11,dense_output=True)
 if not sol.success:raise RuntimeError(sol.message)
 x,w=leggauss(n);t=(x+1)*np.sqrt(umax)/2;w=w*np.sqrt(umax)/2
 u=t*t;r=r0*np.exp(u);delta=sol.sol(u)[0];g,_=gravity(r)
 weight=2*t*g*r/np.sqrt(delta)*w
 return float(C*np.dot(weight,rho2phi(r,p,ra)))
def main():
 df=pd.read_csv(SOURCE)
 df['ra_num']=pd.to_numeric(df.ra_over_a,errors='coerce')
 records=[];errs=[];contours=[]
 for (p,rr),grp in df.groupby(['p','r_energy_over_a'],sort=True):
  iso=float(grp[np.isinf(grp.ra_num)].f_192.iloc[0])
  half=float(grp[np.isclose(grp.ra_num,.5)].f_192.iloc[0])
  b=(half-iso)*(.5**2)
  for _,q in grp.iterrows():
   ra=q.ra_num
   pred=iso if np.isinf(ra) else iso+b/ra**2
   errs.append(abs(pred-q.f_192))
  critical=np.sqrt(-b/iso) if iso*b<0 else np.nan
  records.append(dict(p=p,r_energy_over_a=rr,f_iso=iso,om_coefficient=b,ra_zero_over_a=critical,zero_exists=bool(iso*b<0),f_ra_0p4=iso+b/.4**2,sign_iso=np.sign(iso),sign_b=np.sign(b)))
 out=pd.DataFrame(records);out.to_csv(D/'exact_om_zero_contour.csv',index=False)
 # Roots in energy-radius for selected p and ra, bracketed by step46 samples; exact fresh quadrature.
 for p,ra in [(1.45,.4),(1.5,.4),(1.501,.5),(1.501,1.),(1.501,np.inf),(1.505,.65),(2.,.5),(2.,.65),(2.,1.),(2.,np.inf)]:
  sub=df[(np.isclose(df.p,p)) & ((np.isinf(df.ra_num)) if np.isinf(ra) else np.isclose(df.ra_num,ra))].sort_values('r_energy_over_a')
  x=sub.r_energy_over_a.to_numpy();y=sub.f_192.to_numpy()
  for i in range(len(x)-1):
   if y[i]*y[i+1]>=0:continue
   lo,hi=x[i],x[i+1]
   root=brentq(lambda logrr:one(np.exp(logrr),p,ra,192),np.log(lo),np.log(hi),xtol=2e-9)
   rr=np.exp(root)
   f96=one(rr,p,ra,96);f192=one(rr,p,ra,192);f384=one(rr,p,ra,384)
   contours.append(dict(p=p,ra_over_a=('inf' if np.isinf(ra) else ra),bracket_low=lo,bracket_high=hi,root_r_over_a=rr,f96_at_root=f96,f192_at_root=f192,f384_at_root=f384,abs_f384_minus_f192=abs(f384-f192)))
 pd.DataFrame(contours).to_csv(D/'refined_energy_zero_crossings.csv',index=False)
 summary=dict(step46_input_rows=len(df),affine_identity_max_absolute_error=float(max(errs)),affine_identity_median_absolute_error=float(np.median(errs)),energy_p_pairs=len(out),pairs_with_finite_ra_zero=int(out.zero_exists.sum()),refined_roots=len(contours),root_max_abs_f384=float(max(abs(x['f384_at_root']) for x in contours)) if contours else None,root_max_abs_f384_minus_f192=float(max(x['abs_f384_minus_f192'] for x in contours)) if contours else None)
 import json
 (D/'summary.json').write_text(json.dumps(summary,indent=2))
 print(summary)
 print(pd.DataFrame(contours)[['p','ra_over_a','root_r_over_a','f384_at_root']].to_string(index=False))
if __name__=='__main__':main()
