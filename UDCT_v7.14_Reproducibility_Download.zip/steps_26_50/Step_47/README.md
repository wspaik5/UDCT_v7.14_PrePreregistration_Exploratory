# UDCT v7.14 — Step 47: OM zero-contour audit

Status: exploratory, **not preregistered**, 2026-10-25.

## Reproduction

1. Install `pip install -r requirements.txt`.
2. Place the original Step 46 `om_2d_scan.csv` at `../UDCT_v7_14_Step46_OM_Sign_Map/om_2d_scan.csv` and run `python step47.py`.
3. The ZIP also includes a frozen copy of Step 46 input as `step46_om_2d_scan_input.csv`. To run from the ZIP alone, the script automatically falls back to this local copy.

## Mathematics

For the fixed spherical gravitational potential and the Osipkov–Merritt augmented tracer density,
`rho_OM(r) = rho(r) * [1 + (r/r_a)^2]`, the DF inversion is linear. With `r_a/a` dimensionless,

`f(Q;r_a) = f_iso(Q) + B(Q)/(r_a/a)^2`.

At fixed energy the finite positive zero contour is `r_a/a = sqrt(-B/f_iso)` when `B*f_iso < 0`. This identity is algebraic, not an independent physical proof of DF admissibility.

## Results

- 3,630 Step 46 input rows; 363 distinct (p, energy-radius) combinations.
- Maximum absolute residual of OM affine relation across all original rows: 5.68434e-14.
- 139 of 363 combinations have a finite positive zero-contour value of r_a/a (not all within tested anisotropy grid).
- 13 energy-radius zero crossings refined by Brent root search using new 192-node quadrature; each independently checked with 96 and 384 nodes.
- Maximum absolute 384-node DF at the 192-node roots: 3.46e-9; near steep central transitions, small root errors can magnify the DF residual.

## Files

- `step47.py`: executable analysis and fresh root finding.
- `step46_om_2d_scan_input.csv`: exact Step 46 input copied for stand-alone reproduction.
- `exact_om_zero_contour.csv`: per-(p, energy) affine coefficients and finite OM zero contour.
- `refined_energy_zero_crossings.csv`: bracket, root, quadrature comparisons.
- `summary.json`: machine-readable audit.

## Caveats

This calculation is for a fixed isolated spherical Plummer-generated QUMOND-like gravity law, tracer family rho=(1+(r/a)^p)^(-5/p), and OM inversion. The zero crossing is in the *energy-turning-radius parameter*, not an observed stellar orbital radius or a 3D Hessian/Jeans sign boundary. The simple interpolating g law is fixed in the script; these results are not a universal theorem about MOND. The input data and new root finding share the same gravity/inversion assumptions. Finite-grid nonnegativity does not prove global DF positivity. No direct fit to Hydrus I individual stellar velocities was performed. No prior-art priority claim is made.
