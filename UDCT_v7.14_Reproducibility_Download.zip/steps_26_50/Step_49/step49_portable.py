"""Step49 exploratory negative-lobe scan, using Step47 verified quadrature kernel."""
from pathlib import Path
import sys, json, csv
import numpy as np
from scipy.optimize import brentq, minimize_scalar
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from step47_reference import one
PS=[1.49,1.5,1.501]
RAS=[.35,.4,.45,.5,.65,1.,float('inf')]
RADII=np.geomspace(.06,2.,55)
N=96
rows=[]
for p in PS:
  base=[]
  for r in RADII:
    iso=one(float(r),p,float('inf'),N)
    at_half=one(float(r),p,.5,N)
    base.append((iso,(at_half-iso)*.25))
  for ra in RAS:
    def f_interp(i):
      iso,b=base[i]
      return iso if np.isinf(ra) else iso+b/ra**2
    ys=np.array([f_interp(i) for i in range(len(RADII))])
    brackets=[(float(RADII[i]),float(RADII[i+1])) for i in range(len(ys)-1) if ys[i]*ys[i+1]<0]
    # Direct roots / minima with n=192 to ensure independent high-order verification
    roots=[float(np.exp(brentq(lambda x:one(float(np.exp(x)),p,ra,192),np.log(lo),np.log(hi),xtol=1e-9))) for lo,hi in brackets]
    negative_intervals=[]
    bounds=[float(RADII[0])]+roots+[float(RADII[-1])]
    for lo,hi in zip(bounds[:-1],bounds[1:]):
      mid=np.sqrt(lo*hi)
      if one(mid,p,ra,192)<0:
        result=minimize_scalar(lambda x:one(float(np.exp(x)),p,ra,192),bounds=(np.log(lo),np.log(hi)),method='bounded',options={'xatol':1e-7})
        min_r=float(np.exp(result.x)); min_f=float(result.fun)
        negative_intervals.append((lo,hi,min_r,min_f))
    rows.append(dict(p=p,ra_over_a='inf' if np.isinf(ra) else ra,grid_negative_count=int((ys<0).sum()),roots_count=len(roots),roots=';'.join(f'{x:.10g}' for x in roots),negative_intervals=len(negative_intervals),negative_ranges=';'.join(f'{x[0]:.8g}:{x[1]:.8g}' for x in negative_intervals),minimum_f=min([x[3] for x in negative_intervals],default=''),minimum_r_over_a=min(negative_intervals,key=lambda x:x[3])[2] if negative_intervals else '',note='Domain r/a in [0.06,2]; no global positivity claim'))
  print('finished p',p,flush=True)
with (ROOT/'lobe_map.csv').open('w',newline='') as fh:
  w=csv.DictWriter(fh,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
summary={'p_values':PS,'ra_values':['inf' if np.isinf(v) else v for v in RAS],'r_over_a_scan_range':[float(RADII[0]),float(RADII[-1])],'r_grid_points':len(RADII),'model':'isolated spherical Plummer-generated QUMOND-like gravity, tracer [1+(r/a)^p]^(-5/p), OM','total_parameter_pairs':len(rows),'pairs_with_negative_interval':sum(x['negative_intervals']>0 for x in rows),'quadrature_n_for_brackets':N,'quadrature_n_for_roots_minima':192,'limitations':['Finite r/a domain; zero roots outside interval untested','Shared physical inversion kernel; not independent physics check','Near-tangent zero crossings may escape sign-change scan']}
(ROOT/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
for x in rows: print(x['p'],x['ra_over_a'],x['roots'],x['minimum_f'])
