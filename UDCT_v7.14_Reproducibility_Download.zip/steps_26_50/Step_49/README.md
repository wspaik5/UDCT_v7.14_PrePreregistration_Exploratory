# UDCT v7.14 — Step 49: OM negative-lobe map (exploratory)

This is an exploratory numerical study, **not preregistered** and **not a fit to individual Hydrus I stellar velocities**.

## Model and methods

- Plummer-generated spherical gravitational field, QUMOND-like interpolation `g = 0.5*gN + sqrt(0.25*gN^2 + a0*gN)`.
- Tracer density `rho(r) = [1+(r/a)^p]^(-5/p)`.
- Osipkov–Merritt augmented density `rho_OM = (1+r^2/ra^2)*rho`.
- Inversion implementation imported from the prior Step 47/48 code, included in this archive as `step47_reference.py`.
- Parameters: p = 1.49, 1.5, 1.501; ra/a = 0.35, 0.4, 0.45, 0.5, 0.65, 1, infinity.
- Search r/a in [0.06,2], 55 log-spaced points. 96-node quadrature for brackets and 192-node quadrature for root/minimum refinement.
- `lobe_map.csv` records bracketed roots, intervals and numerical minima. **The r/a variable labels energy via turning radius; it is not a physical orbit-occupancy interval.**

## Main observations

21 parameter pairs, 9 with detected negative intervals in the searched domain. For p=1.5:

| ra/a | roots (r/a) | min f |
|---|---|---|
| 0.35 | 0.1665216234, 0.8545050504 | -0.0020007919203 |
| 0.40 | 0.2237024398, 0.7669697146 | -0.0008538448012 |
| 0.45 | 0.3381470120, 0.6206727785 | -0.0001583586487 |
| 0.50 | none found | n/a |

The two roots approach each other as ra/a grows. This does not yet establish the exact double-root critical point: tangent roots can be missed by sign-change searches. A follow-up should jointly solve f=0 and df/d(log r)=0 and quantify uncertainty.

## Reproduce

```bash
python -m pip install -r requirements.txt
python step49_portable.py
```

Run in the extracted folder. The script expects `step47_reference.py` in a sibling folder `UDCT_v7_14_Step48_Negative_Lobe_Audit` when used in the original workspace. **For this portable ZIP**, the included `step49_portable.py` uses the bundled reference file in the same directory.

## Limitations

- This is a finite-radius search, not proof of global DF positivity.
- Shared physical inversion code and assumptions; numerical agreement does not establish correct physical applicability.
- These results do not prove a failure of QUMOND in general or validate UDCT as an alternative.
- The cusp/anisotropy parameters are synthetic; no direct fit to observed Hydrus I line-of-sight velocities.
