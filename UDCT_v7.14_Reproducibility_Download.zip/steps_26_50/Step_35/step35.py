"""Independent Gauss-Legendre quadrature audit of isolated spherical QUMOND OM DF.
No use of archived step30 df() or its PCHIP potential interpolation.
"""
import numpy as np, csv, json, zipfile
from scipy.special import roots_legendre
from scipy.integrate import quad
from pathlib import Path
P=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=5*6546.; a0=1.2e-10*3.085677581491367e16/1e6; A=G*M
C=1/(np.sqrt(8)*np.pi**2)
def gn(r):return A*r/(r*r+a*a)**1.5
def g(r):
 n=gn(r);return .5*n+np.sqrt(.25*n*n+a0*n)
def dg(r):
 n=gn(r); dn=A*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def derivs(r,q):
 x=r/a;s=1+x*x;b=0 if np.isinf(q) else 1/q**2
 u=1+b*x*x;up=2*b*x;upp=2*b
 v=s**(-2.5);vp=-5*x*s**(-3.5);vpp=-5*s**(-3.5)+35*x*x*s**(-4.5)
 return (up*v+u*vp)/a,(upp*v+2*up*vp+u*vpp)/a**2
def evaluate(r0,q,n=192,outer=1e8):
 # Gauss Legendre in t=sqrt(log(r/r0)), independent of step30 adaptive quad.
 tmax=np.sqrt(np.log(a*outer/r0)); nodes,weights=roots_legendre(n)
 ts=(nodes+1)*tmax/2; ws=weights*tmax/2
 rr=r0*np.exp(ts*ts)
 vals=[]
 for t,r in zip(ts,rr):
  rp,rpp=derivs(r,q); gg=g(r); gp=dg(r)
  rho2=(rpp*gg-rp*gp)/gg**3
  # Exact local potential difference by quadrature in log r (not PCHIP).
  delta=quad(lambda z:g(r0*np.exp(z))*r0*np.exp(z),0,float(t*t),epsabs=1e-12,epsrel=3e-11)[0]
  vals.append(rho2*gg*2*t*r/np.sqrt(delta))
 return C*np.dot(ws,vals)
qs=[.5,.6,np.sqrt(2/5),.65,.75,1.,np.inf]
radii=[1e-5,1e-4,.001,.01,.05,.1,.2,.5,1.,3.,10.]
rows=[]
for q in qs:
 for rv in radii:
  r0=a*rv
  v96=evaluate(r0,q,96);v192=evaluate(r0,q,192)
  rows.append(dict(q='isotropic' if np.isinf(q) else float(q),r_over_a=rv,df_gauss96=v96,df_gauss192=v192,relative_delta=abs(v192-v96)/max(abs(v192),1e-15),sign='negative' if v192<0 else 'positive'))
 print('q',q,'center',rows[-len(radii)]['df_gauss192'],'outer',rows[-1]['df_gauss192'],flush=True)
with (P/'independent_gauss_df.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
# Critical q: leading x^2 term cancels, next x^4 coefficient = 35/8 - (5/2)*(5/2) = -15/8.
critical=float(np.sqrt(2/5))
critical_rows=[r for r in rows if isinstance(r['q'],float) and abs(r['q']-critical)<1e-12]
summary={'method':'independent Gauss-Legendre quadrature with direct quadrature of potential difference; does not call step30 inversion or its PCHIP potential','model':{'a_pc':a,'M_Msun':M,'a0_kms2_per_pc':a0,'external_field':0},'q_critical':critical,'rho_aug_x4_at_critical':-15/8,'n_evaluations':len(rows),'max_relative_96_192':float(max(r['relative_delta'] for r in rows)),'critical_rows':critical_rows,'cautions':['The x^2 coefficient cancels at critical q, so the E^-1/6 term disappears; the next local x^4 term does not by itself determine the full DF sign because the global integral can contribute a finite term.','Positive DF at sampled energies does not imply all-energy positivity.','Convergence of quadrature order does not establish external-field or 3D physical consistency.','Independent numerical quadrature but shared analytic g and rho derivatives; not an independent physical model.']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
print('MAX DELTA',summary['max_relative_96_192'])
