# UDCT v7.14 Step 35 — Independent quadrature audit of OM DF signs

**Status:** exploratory, pre-preregistration. Not a UDCT-specific prediction, 3D external-field test, or direct Hydrus I fit.

## Scope
Independent numerical integration method for the unbounded-potential Abel inversion of a **spherical, isolated, simple-QUMOND Plummer** tracer and source. Stellar mass M=32730 Msun, Plummer a=53.3 pc, a0=1.2e-10 m/s², zero external field. The OM augmented tracer density is rho_aug=(1+r²/ra²)rho_Plummer.

The independent `step35.py` uses fixed-order Gauss-Legendre quadrature in t=sqrt(log(r/r_E)), and **direct adaptive quadrature** for the potential difference Phi(r)-Phi(r_E). It does not import or call the Step30 `df()` or its interpolated potential. Both approaches share the analytic QUMOND acceleration and tracer derivatives; this is an independent integration algorithm, not independent physics.

## Results
- 7 OM/anisotropy cases x 11 turning radii = 77 inversion evaluations, each with 96- and 192-point Gauss quadrature.
- Maximum relative discrepancy (96 vs 192 nodes): about 0.0137%.
- All seven cases contain sampled negative DF values. q=0.5 and 0.6 are positive in the central sample yet negative at intermediate turning radii.
- At q=sqrt(2/5), the local x² term in rho_aug cancels, but the full inversion is numerically negative at the sampled center, ~-0.0006346. The local x^4 term is -15/8 x^4. This local coefficient does NOT determine the sign of the full integral; contributions from larger radii remain.

## Reproduce
```
pip install -r requirements.txt
python step35.py
```
Expected files: `independent_gauss_df.csv`, `results.json`.

## Scientific limits
1. Positivity/negativity applies only to the specified spherical Plummer tracer and isolated simple-QUMOND potential under OM assumptions, not QUMOND in general.
2. A finite 77-point sample can establish negative witnesses for the numerical model but cannot prove global positivity anywhere.
3. High-order quadrature agreement is not a complete error bound; shared formula errors and far-tail approximations remain possible.
4. At critical q, the E^-1/6 leading coefficient vanishes. The full DF can approach a finite value set by the global integral; do not infer sign from the local x^4 coefficient alone.
5. No external-field boundary, full 3D Jeans tensor, observed stellar likelihood, or v7.13 24-case rerun was performed here.
