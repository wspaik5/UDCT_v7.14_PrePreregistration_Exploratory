"""Step32: forward reconstruction convergence audit. Isolated spherical QUMOND only."""
import numpy as np, csv, json, warnings
from scipy.integrate import quad, cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from pathlib import Path
P=Path(__file__).resolve().parent
s=P/'step30_reference.py'
ns={'__file__':str(s)}
exec(compile(s.read_text().split('qs=[.5,')[0],str(s),'exec'),ns)
a=ns['a']; phi=ns['phi']; g=ns['g']; dg=ns['dg']; derivs=ns['derivs']; inv=ns['inv']; C=ns['C']; logr=ns['logr']
# Avoid small t subtraction and costly repeated phi interpolation near t=0 by using analytic limiting kernel.
def df(E,q,rtop=1e8):
    le=float(inv(E)); tmax=np.sqrt(np.log(a*rtop)-le)
    def integrand(t):
        lr=le+t*t; r=np.exp(lr); gg=g(r); gp=dg(r); rp,rpp=derivs(r,q)
        rho2=(rpp*gg-rp*gp)/gg**3
        if t<1e-4:
            # Delta Phi ~ g(r)*r*t²; transformed Abel kernel finite
            return rho2*2*np.sqrt(gg*r)
        delta=float(phi(lr)-E)
        if delta<=0: return rho2*2*np.sqrt(gg*r)
        return rho2*gg*2*t*r/np.sqrt(delta)
    return C*quad(integrand,0,tmax,epsabs=1e-10,epsrel=1e-6,limit=150)[0]
rows=[]; points=[]
for q in [np.inf,1.0]:
    for N in [145,289,577]:
        rgrid=a*np.geomspace(0.01,1e8,N)
        Egrid=np.array([float(phi(np.log(r))) for r in rgrid])
        fgrid=np.array([df(E,q) for E in Egrid])
        for rv in [0.05,0.1,0.2,0.5,1.,3.]:
            E0=float(phi(np.log(a*rv))); f0=df(E0,q)
            # integrate with exact E0 knot, trapezoid quadrature
            keep=Egrid>E0
            EE=np.r_[E0,Egrid[keep]]; ff=np.r_[f0,fgrid[keep]]
            rho=4*np.pi*np.sqrt(2)*np.trapezoid(ff*np.sqrt(np.maximum(EE-E0,0)),EE)
            target=(1+rv*rv)**(-2.5)*(1 if np.isinf(q) else 1+rv*rv/q**2)
            rows.append(dict(q='isotropic' if np.isinf(q) else 'OM_ra=a',N=N,r_over_a=rv,reconstructed=rho,target=target,relative_error=(rho-target)/target,negative_df_grid=int((fgrid<0).sum())))
        print('done',q,N,flush=True)
with (P/'density_convergence.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'method':'QUMOND OM DF inversion; forward density trapezoid over energy samples, Emax corresponds to r/a=1e8','rows':rows,'limitations':['No independent inverse method; same potential and density derivatives reused','Grid refinement only; inner energy endpoint r/a=0.01 and outer cutoff finite','Spherical isolated Plummer stellar mass; not Hydrus I velocity fit or 3D EFE','Negative DF indicates this prescribed equilibrium ansatz may fail, not general QUMOND failure']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
