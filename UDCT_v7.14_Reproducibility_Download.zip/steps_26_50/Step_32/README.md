# UDCT v7.14 Step 32 — exploratory DF reconstruction convergence

This is a **pre-preregistration numerical audit**, not a claim of observational validation or a general no-go theorem.

## Model
Isolated spherical QUMOND simple interpolation, Plummer stellar source and tracer, scale radius 53.3 pc, stellar mass 5 × 6546 solar masses. Compare isotropic and Osipkov–Merritt anisotropy radius r_a=a. The gravitational potential increases logarithmically at large radius; energy convention E=v²/2+Phi, Phi(0)=0.

## Method
Run `python step32.py` (requires numpy and scipy). It evaluates the Abel-inverted DF at 145, 289, and 577 logarithmically spaced radii from 0.01a to 1e8a and forward-integrates the sampled DF against sqrt(E-Phi) to reconstruct the augmented tracer density. `step30_reference.py` preserves original Step30 formulas.

## Interpretation
The density reconstruction errors decrease as energy grid resolution increases. Negative DF samples persist. This is an exploratory self-consistency check, **not independent confirmation**, because forward and inverse calculations share the same potential and derivatives. No complete 3D external field, Hydrus I star-by-star likelihood, or original v7.13 24-candidate sign test is performed.

## Known limitations
Finite energy range, finite radial extent, numerical quadrature, sparse outer-grid energy samples; positivity cannot be certified globally. The DF sign must be tested with an independent inversion and distribution consistency checks before strong claims.
