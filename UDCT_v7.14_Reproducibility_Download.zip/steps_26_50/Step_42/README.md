# UDCT v7.14 Step 42 — Forward density reconstruction audit

Status: exploratory, pre-preregistration. 2026-10-25.

## Aim
Test whether the signed distribution function recovered using the right-sided Abel inversion reconstructs the input tracer density. This is an internal consistency check, **not** a proof of physical DF positivity, observational fit, or a general failure of QUMOND.

## Model
Spherical isolated QUMOND with Plummer gravitating mass M=32730 Msun, a=53.3 pc, acceleration scale a0=1.2e-10 m/s^2, simple nu(x)=0.5+sqrt(0.25+1/x). Tracer density rho(r)/rho0=[1+(r/a)^p]^(-5/p). Spherical potential is defined by dPhi/dr=g(r)>0; its zero-point cancels from integrals. In an isolated deep-MOND exterior, Phi diverges logarithmically, so the relevant inversion is the right-sided Abel transform over Phi to +infinity.

rho(Phi)=4*pi*sqrt(2)*integral_Phi^infinity f(E)*sqrt(E-Phi) dE
f(E)=1/(sqrt(8)*pi^2)*integral_E^infinity rho''(Phi)/sqrt(Phi-E) dPhi

## Procedure
The Python script evaluates g, dg/dr, rho', rho'', constructs Phi(r) by cumulative quadrature on a logarithmic radial grid, obtains rho''(Phi), performs inverse Abel quadrature with endpoint substitution, then forward-integrates the resulting signed f to recover rho. Compare 900 and 1400 radial grid points; Gauss-Legendre order 112. Outer cutoff rmax/a=1e6. Reconstruction at r/a=1e-4,1e-3,1e-2,0.1,0.5,1,3,10. Four density exponents p=1.49,1.5,1.501,2.0.

## Results
Maximum absolute relative errors (900 -> 1400):
- p=1.49: 0.0479682% -> 0.0176101%
- p=1.50: 0.0479707% -> 0.0176108%
- p=1.501: 0.0479709% -> 0.0176109%
- p=2.0: 0.0480009% -> 0.0175984%

At 1400 samples, 0 negative DF samples for p=1.49 and 1.50; 529 for p=1.501; 838 for p=2.0 (of 1399 non-endpoint energy samples). Counts are grid-dependent, not fractions of physical phase space. A negative DF may still reproduce a positive density because the integral allows cancellation. Hence reconstruction is a necessary algebraic/numerical consistency test, not a positivity test.

## Limitations / next audits
- Finite outer radius truncates the formal infinity; no explicit cutoff sweep yet.
- Inversion and reconstruction share the same interpolated potential and density derivatives, so systematic errors could be shared.
- Errors only reported at eight radii, not a continuous supremum bound.
- Very small central radii and density normalization require further convergence tests.
- The p=3/2 critical exponent is model-specific and not a demonstrated novel result in prior literature.
- Not a direct fit of individual Hydrus I stellar line-of-sight velocities; no 3D EFE or v7.13 B01–B24 rerun.

## Reproduce
`python -m pip install -r requirements.txt`
`python step42.py`
Results: density_reconstruction.csv and summary.json.
