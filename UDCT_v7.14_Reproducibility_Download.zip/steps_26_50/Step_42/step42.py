import numpy as np, csv, json
from pathlib import Path
from scipy.integrate import cumulative_trapezoid
from scipy.interpolate import PchipInterpolator
from scipy.special import roots_legendre
D=Path(__file__).resolve().parent
G=4.30091e-3;a=53.3;M=32730.;a0=1.2e-10*3.085677581491367e16/1e6
C=1/(np.sqrt(8)*np.pi**2)
def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+np.sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5;dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def deriv(r,p):
 y=(r/a)**p;rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y));Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 return rho*L,rho*(L*L+Lp)
def run(p, rmax=1e6, ngrid=900, nq=112):
 # log radial grid, potential from g(r) dr, offset irrelevant
 x=np.linspace(np.log(1e-11),np.log(rmax),ngrid);r=a*np.exp(x)
 grav=g(r);phi=cumulative_trapezoid(grav*r,x,initial=0)
 d1,d2=deriv(r,p)
 d2rho=(d2*grav-d1*gp(r))/grav**3
 pp=PchipInterpolator(phi,d2rho,extrapolate=False)
 # f(phi_i) via substitution phi'=phi_i+(phi_max-phi_i)t²
 nodes,weights=roots_legendre(nq);t=(nodes+1)/2;w=weights/2
 energy=phi[:-1];delta=phi[-1]-energy
 f=np.empty(ngrid);f[-1]=0.
 for i in range(ngrid-1):
  v=pp(energy[i]+delta[i]*t*t)
  f[i]=C*2*np.sqrt(delta[i])*np.dot(w,v)
 # reconstruct using f(phi+u²) : rho=4pi sqrt2 integral_phi^max f(E)sqrt(E-phi)dE
 fp=PchipInterpolator(phi,f,extrapolate=False)
 recon=[]
 for rr in [1e-4,1e-3,1e-2,.1,.5,1,3,10]:
  target=float(np.interp(np.log(rr),x,phi));end=phi[-1]-target
  # weighted smooth integration with v=sqrt(E-target); integrand 2v² f(target+v²)
  v=np.sqrt(end)*t
  rec=4*np.pi*np.sqrt(2)*2*np.sqrt(end)*np.dot(w,v*v*fp(target+v*v))
  expected=(1+rr**p)**(-5/p)
  recon.append(dict(p=p,r_over_a=rr,rho_true=expected,rho_reconstructed=rec,relative_error=(rec-expected)/expected))
 signs=dict(p=p,negative_samples=int(np.sum(f<0)),positive_samples=int(np.sum(f>0)),f_min=float(np.min(f)),f_max=float(np.max(f)),rmax_over_a=rmax,ngrid=ngrid,nq=nq)
 return recon,signs
if __name__=='__main__':
 rows=[];meta=[]
 for p in [1.49,1.5,1.501,2.0]:
  for n in [900,1400]:
   rr,ss=run(p,ngrid=n);rows.extend([dict(ngrid=n,**q) for q in rr]);meta.append(ss)
   print('p',p,'grid',n,'max relative error',max(abs(v['relative_error']) for v in rr),flush=True)
 with (D/'density_reconstruction.csv').open('w',newline='') as file:
  wr=csv.DictWriter(file,fieldnames=rows[0].keys());wr.writeheader();wr.writerows(rows)
 (D/'summary.json').write_text(json.dumps({'cases':meta,'warning':'Finite outer cutoff and interpolation; no positivity inference from density reconstruction alone','max_abs_relative_error_by_case':[{'p':q['p'],'ngrid':q['ngrid'],'max_abs_relative_error':max(abs(v['relative_error']) for v in rows if v['p']==q['p'] and v['ngrid']==q['ngrid'])} for q in meta]},indent=2))
