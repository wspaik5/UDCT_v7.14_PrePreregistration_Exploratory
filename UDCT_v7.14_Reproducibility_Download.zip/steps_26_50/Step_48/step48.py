from pathlib import Path
import json,csv
import numpy as np
from scipy.optimize import brentq, minimize_scalar
from step47_reference import one
D=Path(__file__).resolve().parent
# Fixed model p=1.5, ra/a=0.4, find energy-radius zeros and minimum.
p=1.5;ra=0.4
# Search logarithmic radius and refine using same model at different quadrature orders.
logr=np.linspace(np.log(0.06),np.log(3.0),81)
values=np.array([one(float(np.exp(x)),p,ra,192) for x in logr])
roots=[]
for i in range(len(logr)-1):
 if values[i]*values[i+1]<0:
  root=brentq(lambda x:one(float(np.exp(x)),p,ra,192),logr[i],logr[i+1],xtol=1e-10)
  roots.append(float(np.exp(root)))
if len(roots)!=2: raise RuntimeError(f'Expected two roots, found {roots}')
res=minimize_scalar(lambda x:one(float(np.exp(x)),p,ra,192),bounds=(np.log(roots[0]),np.log(roots[1])),method='bounded',options={'xatol':1e-9})
minr=float(np.exp(res.x)); minf=float(res.fun)
rows=[]
for kind,r in [('left_zero',roots[0]),('minimum',minr),('right_zero',roots[1])]:
 row={'kind':kind,'r_over_a':r}
 for n in (96,192,384):row[f'f_{n}']=one(r,p,ra,n)
 rows.append(row)
with (D/'roots_and_minimum.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# width of negative region in radius and in log radius; energy map is monotone but not linear.
summary={'model':'isolated spherical Plummer-generated QUMOND-like law; p=1.5, ra/a=0.4','left_root_r_over_a':roots[0],'right_root_r_over_a':roots[1],'negative_interval_width_r_over_a':roots[1]-roots[0],'negative_interval_width_log_r':float(np.log(roots[1]/roots[0])),'minimum_r_over_a':minr,'minimum_f_192':minf,'min_f_96':rows[1]['f_96'],'min_f_384':rows[1]['f_384'],'max_abs_384_minus_192_at_landmarks':max(abs(row['f_384']-row['f_192']) for row in rows)}
(D/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
