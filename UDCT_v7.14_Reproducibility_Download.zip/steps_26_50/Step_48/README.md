# UDCT v7.14 Step 48 — negative OM distribution-function lobe

Exploratory audit, not preregistration. Model: fixed isolated spherical Plummer-generated QUMOND-like acceleration, tracer density rho=(1+(r/a)^p)^(-5/p), OM augmented density rho_OM=(1+r^2/r_a^2)rho. Parameters p=1.5 and r_a/a=0.4.

## Reproduction

Install `pip install -r requirements.txt`; run `python step48.py`. `step47_reference.py` is bundled for standalone operation. The script computes the DF using the radial integral and a Gauss–Legendre quadrature with a numerical potential difference, searches for the two zero crossings and minimizes the DF between them, and repeats at 96, 192, 384 nodes.

## Findings

See `summary.json` and `roots_and_minimum.csv`. The zero crossings in the *energy-label radius* r/a are 0.2237024398 and 0.7669697146; minimum f=-0.0008538448012 at r/a=0.3804964036. The negative-lobe width in this radius coordinate is 0.5432672748. This is not a physical radial interval containing negative stellar densities: r labels energy, and f<0 denotes failure of the assumed OM DF positivity at those energies.

## Caveats

The 96/192/384 comparisons share the same inversion and gravity assumptions. This does not establish a global positive DF elsewhere, nor rule out other tracer or anisotropy models. No direct Hydrus I individual-star velocity fitting, 3D EFE, or v7.13 24-candidate retest is included. It is not a universal MOND failure theorem. Future work: systematic grid of (p,ra), bracketed roots, sensitivity to outer boundary, and independent forward density reconstruction.
