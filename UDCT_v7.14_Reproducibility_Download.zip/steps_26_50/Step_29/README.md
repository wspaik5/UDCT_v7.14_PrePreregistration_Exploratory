# UDCT v7.14 — Step 29: QUMOND OM DF admissibility preflight

**Status:** exploratory, before preregistration. This package DOES NOT establish QUMOND distribution-function positivity.

## Reproduce

`pip install -r requirements.txt` then `python step29.py`. Outputs: `necessary_condition.csv`, `potential_tail.csv`, `outer_reference_sensitivity.csv`, and `results.json`.

## Model and equations

Spherical Plummer tracer and source, scale a=53.3 pc, luminosity 6546 Lsun, M/L=5 -> stellar mass M=32730 Msun. Isolated QUMOND with simple nu function `nu(y)=0.5+sqrt(0.25+1/y)` and a0=1.2e-10 m/s^2. The acceleration is `g_Q(r)=nu(g_N/a0)*g_N` where `g_N=GM r/(r²+a²)^(3/2)`. This spherical algebraic expression is valid in the isolated spherical limit; it is NOT the nonspherical 3D external-field solution.

OM augmented tracer density `rho_aug(r)=[1+(r/ra)^2]rho(r)`. A nonnegative OM DF implies `d rho_aug/d Psi >= 0` for the usual finite-escape inversion (and, more generally, monotonicity of the corresponding velocity integral). Since `dPsi/dr=-g<0`, this requires `d rho_aug/dr<=0`. For Plummer density this is equivalent to `ra/a >= sqrt(2/5)=0.6324555` (derivative at the center understood as limit). This is ONLY A NECESSARY CONDITION, not proof of DF positivity. Do not substitute the Newtonian full positivity bound 0.75 for this necessary bound.

## Critical obstruction to naive Step28 reuse

For isolated QUMOND at large r, `g_Q(r) ~ sqrt(G M a0)/r`; thus `Phi(r)~sqrt(G M a0) log(r)` diverges at infinity. There is no finite escape-energy reference at infinity. The finite-escape Eddington inversion used in Step28 CANNOT be carried over unchanged. A consistent full DF treatment needs a formulation for unbounded potentials, a physically justified truncation, or an external-field model with appropriate boundary conditions. Merely truncating at arbitrary R changes the energy reference and may introduce an artificial edge.

`outer_reference_sensitivity.csv` numerically demonstrates the logarithmic increase of potential difference from a to R. `potential_tail.csv` checks the asymptotic coefficient.

## Limitations

- No QUMOND DF inversion or full positivity certification performed.
- No nonspherical 3D DF, external-field model, or 3D Jeans tensor solution.
- No Hydrus I individual-star observational likelihood.
- No rerun of v7.13 B01-B24 sign-boundary candidates.
- This is a known structural property of isolated MOND-like potentials, not a new gravity discovery.
