"""Step29: QUMOND spherical DF inversion preflight; necessary OM density condition and log potential tail.
No DF positivity claim. Units: pc, km/s, Msun.
"""
import csv,json,math
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq
P=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=5*6546.0
# a0=1.2e-10 m/s2 to (km/s)^2/pc
a0=1.2e-10*(3.085677581491367e16)/1e6

def gn(r):return G*M*r/(r*r+a*a)**1.5
def nu_simple(y):return .5+math.sqrt(.25+1/y)
def gq(r):return gn(r)*nu_simple(gn(r)/a0)
def rho(r):return (1+(r/a)**2)**(-2.5)
def aug(r,ra):return rho(r)*(1+(r/ra)**2) if math.isfinite(ra) else rho(r)
def dlnaug_dr(r,ra):
    return -5*r/(a*a+r*r)+(2*r/(ra*ra+r*r) if math.isfinite(ra) else 0)
def d_aug_dpsi(r,ra):return -aug(r,ra)*dlnaug_dr(r,ra)/gq(r)
# central derivative criterion from r->0; r=0 itself 0/0 in d rho / dpsi.
rows=[]
for ratio in [.5,.6,math.sqrt(2/5),.65,.7,.749,.75,1.,2.,5.,math.inf]:
    ra=a*ratio
    radii=a*np.geomspace(1e-4,1e4,1501)
    deriv=np.array([d_aug_dpsi(float(r),ra) for r in radii]); negative=deriv < -1e-12
    # analytical radius at which derivative switches, if any
    # 2/(ra^2+r^2) - 5/(a^2+r^2) =0 => r²=(2a²-5ra²)/3
    zero=(math.sqrt(max(0.,(2*a*a-5*ra*ra)/3))/a if math.isfinite(ra) and ratio<math.sqrt(2/5) else None)
    rows.append({'ra_over_a':'isotropic' if math.isinf(ratio) else round(ratio,9), 'min_drho_aug_dPsi':float(deriv.min()), 'negative_grid_points':int(negative.sum()), 'necessary_condition_pass':bool(not negative.any()),'sign_change_r_over_a':zero})
with (P/'necessary_condition.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# tail check for isolated QUMOND g~sqrt(GMa0)/r, Newtonian g~GM/r²
v2=math.sqrt(G*M*a0)
tail=[]
for r_a in [10,30,100,300,1000,3000,10000]:
 r=r_a*a;tail.append({'r_over_a':r_a,'r_times_gQ':r*gq(r),'asymptotic_sqrt_GMa0':v2,'relative_difference':r*gq(r)/v2-1})
with (P/'potential_tail.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(tail[0]));w.writeheader();w.writerows(tail)
# potential drop from a to R: integral g(r)dr. grows ~ v² log(R/a)
pot=[]
for R_a in [10,100,1000,10000]:
 delta=quad(lambda t:gq(a*math.exp(t))*a*math.exp(t),0,math.log(R_a),epsrel=1e-10)[0]
 pot.append({'outer_R_over_a':R_a,'Phi_R_minus_Phi_a':delta,'dimensionless_by_v2':delta/v2})
with (P/'outer_reference_sensitivity.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(pot[0]));w.writeheader();w.writerows(pot)
assert all(r['necessary_condition_pass'] for r in rows if r['ra_over_a']=='isotropic' or isinstance(r['ra_over_a'],float) and r['ra_over_a']>=math.sqrt(2/5)+1e-5)
assert rows[0]['negative_grid_points']>0
assert pot[-1]['Phi_R_minus_Phi_a']>pot[0]['Phi_R_minus_Phi_a']
summary={'title':'UDCT v7.14 Step29 QUMOND DF inversion preflight','model':{'a_pc':a,'stellar_mass_Msun':M,'G_pc_kms2_Msun':G,'a0_kms2_per_pc':a0,'nu':'simple','external_field':0},'necessary_OM_condition':'d rho_aug / d Psi >= 0 for nonnegative f(Q), where rho_aug=(1+r²/ra²)rho; for Plummer requires ra/a >= sqrt(2/5) ~ 0.63246','important':'Necessary condition only; passing does NOT establish positive distribution function','obstruction':'Isolated QUMOND asymptotic potential Phi~sqrt(G*M*a0)*ln(r), diverges as r->infinity; finite-escape relative-potential Eddington inversion from Step28 cannot be reused unchanged','samples':rows,'tail':tail,'outer_reference':pot,'limitations':['No Eddington inversion of QUMOND DF performed','No QUMOND OM positivity threshold established','No external field or nonspherical 3D DF','No Hydrus I direct stellar likelihood','No v7.13 B01-B24 rerun']}
(P/'results.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False))
print('a0',a0,'M',M,'v2',v2)
for x in rows:print('ra/a',x['ra_over_a'],'negative points',x['negative_grid_points'],'necessary pass',x['necessary_condition_pass'])
for x in pot:print('R/a',x['outer_R_over_a'],'deltaPhi',x['Phi_R_minus_Phi_a'])
