"""Step28: analytic Eddington inversion for self-consistent Newtonian Plummer OM models.
This is NOT a QUMOND DF inversion or a direct Hydrus I observational fit.
"""
import csv,json
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.special import beta as beta_fn
P=Path(__file__).resolve().parent
C3=3*2*beta_fn(2,.5)
C5=5*4*beta_fn(4,.5)
assert abs(C3-8)<1e-12 and abs(C5-128/7)<1e-12

def fscaled(u,ra):
    q=1/(ra*ra) if np.isfinite(ra) else 0.
    return (1-q)*C5*u**3.5+q*C3*u**1.5

def rho_augmented(u,ra):
    q=1/(ra*ra) if np.isfinite(ra) else 0.
    return (1-q)*u**5+q*u**3

def reconstructed_density(u,ra):
    val=quad(lambda x:fscaled(x,ra)*np.sqrt(u-x),0,u,epsabs=2e-12)[0]
    return 2/np.pi*val

rows=[]
for ra in [0.5,0.7,0.749,0.75,0.751,1.,2.,5.,float('inf')]:
    us=np.linspace(.0001,1,2001)
    f=fscaled(us,ra)
    recon_errors=[abs(reconstructed_density(u,ra)-rho_augmented(u,ra)) for u in (.1,.25,.5,.75,1.)]
    q=0 if np.isinf(ra) else 1/ra**2
    cross=(q*C3/((q-1)*C5))**.5 if q>1 else None
    rows.append(dict(ra_over_a=('isotropic' if np.isinf(ra) else ra),q=q,min_fscaled=float(f.min()),fscaled_at_Qmax=float(f[-1]),negative_samples=int(np.sum(f < -1e-12)),positive_all_energies=bool(f.min()>=-1e-12),zero_crossing_Q_over_Psi0=cross if cross is not None and cross<=1 else '',max_density_reconstruction_abs_error=float(max(recon_errors))))
with (P/'om_distribution_positivity.csv').open('w',newline='') as fh:
    w=csv.DictWriter(fh,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
summary={'title':'UDCT v7.14 Step28 Newtonian Plummer OM DF admissibility audit','scope':'Self-consistent isotropic/Osipkov-Merritt Newtonian Plummer only; analytic Eddington inversion plus numerical density reconstruction','formula':'f(Q)=[rho0/(sqrt(8)*pi^2*Psi0^(3/2))]*[(1-q)*(128/7)*u^(7/2)+8*q*u^(3/2)], u=Q/Psi0, q=(a/ra)^2','analytic_threshold':'ra/a >= 3/4 for all nonnegative f(Q), 0<Q<=Psi0','samples':rows,'max_reconstruction_error':max(x['max_density_reconstruction_abs_error'] for x in rows),'constant_beta_positive':'Excluded for cored Plummer under central cusp-slope anisotropy theorem (beta0<=gamma0/2=0); not a proof for tangential beta<0','limitations':['This DF inversion is for Newtonian Plummer potential, not the QUMOND force of Step27','OM DF positivity is not a full 3D external-field or observed-star fit','No claim that Step27 QUMOND OM models are phase-space admissible','Not a rerun of v7.13 B01-B24']}
(P/'results.json').write_text(json.dumps(summary,indent=2,allow_nan=False))
for r in rows:print('ra/a',r['ra_over_a'],'min f*',round(r['min_fscaled'],6),'neg',r['negative_samples'],'max rho error',f"{r['max_density_reconstruction_abs_error']:.2e}")
print('max density error',summary['max_reconstruction_error'])
