# UDCT v7.14 — Step 28: Phase-space DF positivity

**Status:** Exploratory, before preregistration. This is a Newtonian Plummer Osipkov–Merritt benchmark, **not** a QUMOND distribution-function inversion, a 3D Jeans solution, or a fit to individual Hydrus I stars.

## Reproduce

`python step28.py` with Python, numpy and scipy installed. This creates `om_distribution_positivity.csv` and `results.json`.

## Method

For a self-consistent Newtonian Plummer sphere with relative potential `Psi(r)=GM/sqrt(r^2+a^2)` and OM augmented density `rho_Q(r)=(1+r^2/ra^2)rho(r)`, define `u=Q/Psi0`, `q=(a/ra)^2`, `Psi0=GM/a`. Then `rho_Q/rho0=(1-q)u^5+q u^3`. Eddington inversion yields

`f(Q) = rho0/(sqrt(8)*pi^2*Psi0^(3/2)) * [ (1-q)*(128/7)*u^(7/2) + 8*q*u^(3/2) ]`.

The nonnegative DF criterion for all `0<Q<=Psi0` is exactly `q<=16/9`, i.e. `ra/a>=3/4`. The script checks 2001 energies and independently reconstructs the augmented density by quadrature at five potential values for each model. Negative DF at `ra/a=0.5` and positive DF at `ra/a>=0.75` are not new physical discoveries; this is a code and physical-admissibility benchmark.

For a cored Plummer tracer, the central cusp-slope anisotropy theorem excludes constant positive central beta (`gamma0=0` implies `beta0<=0`) under its assumptions. Tangential constant beta values are not certified by this test.

## Interpretation and limitations

- The Step27 isolated spherical QUMOND Jeans calculations are **not** validated as phase-space consistent by this Newtonian DF test.
- No external field, nonspherical potential, true 3D Jeans tensor solution, or observational likelihood has been tested here.
- No v7.13 B01–B24 candidate has been replayed.
- Numerical DF positivity is checked over a finite energy grid, while the stated threshold follows the **analytic formula**, not the grid alone.
