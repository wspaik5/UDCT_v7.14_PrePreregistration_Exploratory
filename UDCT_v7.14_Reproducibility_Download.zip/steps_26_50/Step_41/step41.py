import numpy as np,csv,json
from scipy.integrate import quad
from scipy.special import beta
from pathlib import Path
D=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=32730.; a0=1.2e-10*3.085677581491367e16/1e6
C=1/(np.sqrt(8)*np.pi**2); k=G*M/a**3; A=2*np.sqrt(a0*k)/3

def g(r):
 n=G*M*r/(r*r+a*a)**1.5
 return .5*n+np.sqrt(.25*n*n+a0*n)
def gp(r):
 n=G*M*r/(r*r+a*a)**1.5;dn=G*M*(a*a-2*r*r)/(r*r+a*a)**2.5
 return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def deriv(r,p):
 y=(r/a)**p;rho=(1+y)**(-5/p)
 L=-5*y/(r*(1+y)); Lp=5*y*(1+y-p)/(r*r*(1+y)**2)
 return rho*L,rho*(L*L+Lp)
def potential_diff(r0,r):
 return quad(lambda t:g(np.exp(t))*np.exp(t),np.log(r0),np.log(r),epsabs=1e-12,epsrel=1e-11,limit=200)[0]
def integrand_t(t,r0,p):
 if t==0: t=1e-10
 r=r0*np.exp(t*t)
 d1,d2=deriv(r,p);gr=g(r)
 rho_pp=(d2*gr-d1*gp(r))/gr**3
 delta=potential_diff(r0,r)
 return rho_pp*gr*2*t*r/np.sqrt(delta)
def invert(r0,p,upper=1e6,eps=1e-7):
 # independent adaptive QUAD, no interpolated potential or Gauss-Legendre quadrature
 T=np.sqrt(np.log(upper*a/r0))
 result,err=quad(lambda t:integrand_t(t,r0,p),0,T,epsabs=eps,epsrel=eps,limit=200)
 return C*result,C*err
ps=[1.49,1.499,1.5,1.501,1.51,1.55,2.0]
rs=[1e-4,1e-6,1e-8]
rows=[]
for p in ps:
 for rv in rs:
  v,e=invert(rv*a,p)
  rows.append(dict(p=p,r_over_a=rv,f_adaptive=v,quad_error_est=e,sign='positive' if v>0 else 'negative'))
  print(p,rv,v,flush=True)
with (D/'independent_adaptive.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
(D/'summary.json').write_text(json.dumps({'method':'adaptive scipy QUAD with potential integrated on demand; no PCHIP; independent quadrature, same analytical inversion identity','rows':rows},indent=2))
