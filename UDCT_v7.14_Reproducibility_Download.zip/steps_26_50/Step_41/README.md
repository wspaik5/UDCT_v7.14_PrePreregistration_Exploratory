# UDCT v7.14 — Step 41: Independent quadrature audit

Status: pre-preregistration exploratory numerical audit, 2026-10-25.

## What was independently changed

Step 40 used a tabulated/interpolated potential and Gauss–Legendre quadrature. This step computes potential differences by adaptive scipy.integrate.quad on every integrand evaluation, and independently evaluates the outer inversion integral using adaptive QUAD. No potential interpolation or Legendre nodes are used. The same underlying isotropic Abel inversion equation and the same spherical Plummer-QUMOND physical assumptions are retained; this is NOT an independent derivation of that equation.

## Model

G=4.30091e-3 pc (km/s)^2/Msun; M=32730 Msun; a=53.3 pc; a0=1.2e-10 m/s^2.

gN=G*M*r/(r*r+a*a)^1.5; g=gN/2+sqrt(gN*gN/4+a0*gN).

Tracer rho=(1+(r/a)^p)^(-5/p), isotropic DF; potential Phi(r)-Phi(0) unbounded as r tends to infinity. f(E) = 1/(sqrt(8)*pi^2) integral_E^infty rho''(Psi)/sqrt(Psi-E) dPsi. The integral is numerically truncated at r=1e6 a, with the tail not rigorously bounded in this step.

## Run

pip install -r requirements.txt
python step41.py

Outputs: independent_adaptive.csv, summary.json. comparison.csv compares against Step 40 (precomputed, included in ZIP). 21 calculations: 7 exponents by 3 radii. The calculations agree closely with Step 40, supporting numerical implementation robustness rather than independent physical validation.

## Cautions

* A local center asymptotic sign boundary at p=3/2 is not a global physical admissibility criterion.
* At p=3/2 the leading singular term vanishes and subleading contributions determine the sign.
* No velocity anisotropy, external field, 3D Jeans, or Hydrus I star-by-star fit was computed here.
* A separate inversion identity derivation, upper-tail bound, and global DF reconstruction should be audited before publication.
