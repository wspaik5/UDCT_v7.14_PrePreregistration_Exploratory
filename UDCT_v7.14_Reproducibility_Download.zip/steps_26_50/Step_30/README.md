# UDCT v7.14 Step 30 — Isolated spherical QUMOND DF inversion (exploratory)

This package is an actual numerical run, not preregistration. Execute `python step30.py` and `python newtonian_control.py` (NumPy/SciPy). All data in the package are generated, not observational Hydrus I velocities.

## Assumptions
- Plummer mass/tracer density, a=53.3 pc, stellar mass M=32730 solar masses, G=4.30091e-3 pc (km/s)^2/Msun, a0=1.2e-10 m/s².
- Isolated spherical QUMOND with simple nu(y)=0.5+sqrt(0.25+1/y), g_Q=nu(g_N/a0)g_N.
- Osipkov–Merritt augmented density rho_aug=(1+r²/ra²)rho(r); isotropic ra=infinity.
- Positive-energy convention E=v²/2+Phi(r), Phi(0)=0, Phi(infinity)=infinity. For the unbounded potential, rho_aug(Phi) tends to zero as Phi tends to infinity.

## Method
Abel inversion f(E) = [1/(sqrt(8) pi²)] integral_E^infinity rho_aug''(Phi)/sqrt(Phi-E) dPhi. Integrate over radius after substitution ln(r/r_E)=t² to eliminate endpoint square-root singularity. rho_aug''(Phi)=[rho_aug''(r) g(r)-rho_aug'(r) g'(r)]/g(r)^3. Phi(r) integrated on 16001 log-radius points from r/a=1e-7 to 1e8 and interpolated monotonically.

## Results and interpretation
- `df_positivity_scan.csv`: 11 anisotropy conditions x 43 energies; negative f values appear in all 11 scans, including isotropic case. These are findings **for this specific model**, not general no-go statements for MOND, QUMOND, or UDCT.
- `df_q_*.csv`: selected full DF curves.
- `newtonian_control.csv`: numerical inversion agrees with exact Newtonian Plummer DF to ~3e-11 relative or better at 8 points, validating the kernel for a known potential.
- `spot_checks.csv`: selected QUMOND samples.
- Negative f(E) is distinct from negative Jeans velocity dispersion and from negative Hessian eigenvalues.

## Outstanding validation
- Numerical upper integration bound r/a=1e8; no analytic tail correction. Test upper-bound stability and interpolation stability.
- Density reconstruction from f(E) was not carried out; strongly recommended before declaring a rigorous DF nonexistence result.
- Only sampled 43 energy values per model; not a continuous sign proof.
- Spherical isolated QUMOND, no external field; no full 3D axisymmetric DF, no Hydrus I individual-star direct likelihood.
- v7.13 B01–B24 candidate sign transitions not rerun.

## Scientific status
Exploratory numerical evidence of negative DF for these imposed stellar profiles, subject to further convergence and physical-model checks. No preregistered confirmatory result.
