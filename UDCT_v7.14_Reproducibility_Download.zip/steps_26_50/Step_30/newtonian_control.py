"""Independent Newtonian isotropic Plummer control for the same Abel kernel."""
import numpy as np,csv,json
from scipy.integrate import quad
from pathlib import Path
P=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=5*6546.; A=G*M
C=1/(np.sqrt(8)*np.pi**2)
def gn(r):return A*r/(r*r+a*a)**1.5
def dgn(r):return A*(a*a-2*r*r)/(r*r+a*a)**2.5
def phi(r):return A/a*(1-1/np.sqrt(1+(r/a)**2))
def rho_deriv(r):
 x=r/a;s=1+x*x
 return -5*x*s**(-3.5)/a,(-5*s**(-3.5)+35*x*x*s**(-4.5))/a**2
def fnum(rE):
 E=phi(rE)
 def fn(t):
  if t==0:t=1e-9
  r=rE*np.exp(t*t);gg=gn(r);gp=dgn(r);rp,rpp=rho_deriv(r)
  return ((rpp*gg-rp*gp)/gg**3)*gg*2*t*r/np.sqrt(max(phi(r)-E,1e-28))
 return C*quad(fn,0,np.sqrt(np.log(a*1e8/rE)),epsrel=1e-7,limit=200)[0]
# analytic Plummer f(E) for Phi(0)=0, escape energy A/a:
# rho(Phi)=(1-Phi/(A/a))^5, so f(E)= (24 sqrt(2)/(7 pi^3)) (a/A)^(3/2) [1-E/(A/a)]^(7/2) ?
# exact via second derivative Abel: 20/(sqrt8 pi² (A/a)^2) * B(1/2,4) * (A/a-E)^(7/2)
from scipy.special import beta
rows=[]
for ratio in [.015,.03,.1,.3,1,3,10,100]:
 r=a*ratio; E=phi(r)
 exact=C*20/(A/a)**5*beta(.5,4)*(A/a-E)**3.5
 numerical=fnum(r)
 rows.append({'r_over_a':ratio,'E':E,'numeric':numerical,'analytic':exact,'rel_err':numerical/exact-1})
with (P/'newtonian_control.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(rows)
assert max(abs(z['rel_err']) for z in rows[:6])<.005
