"""Isolated spherical QUMOND Osipkov-Merritt DF inversion for unbounded potential.
Physical model is a Plummer tracer and stellar-source density, no external field.
Units pc, km/s, Msun; energy E = v²/2 + Phi(r), Phi(0)=0.
"""
import numpy as np, csv, json
from scipy.integrate import cumulative_trapezoid, quad
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq
from pathlib import Path
P=Path(__file__).resolve().parent
G=4.30091e-3; a=53.3; M=5*6546.; a0=1.2e-10*3.085677581491367e16/1e6
A=G*M

def gn(r): return A*r/(r*r+a*a)**1.5
def g(r):
    n=gn(r); return .5*n+np.sqrt(.25*n*n+a0*n)
def dg(r):
    n=gn(r); dn=A*(a*a-2*r*r)/(r*r+a*a)**2.5
    return dn*(.5+(.5*n+a0)/(2*np.sqrt(.25*n*n+a0*n)))
def derivs(r,q):
    x=r/a; s=1+x*x
    # rho_aug = s^-5/2 * (1+x²/q²), rho0 normalized to 1
    b=0 if np.isinf(q) else 1/q**2
    # product derivative w.r.t x
    u=1+b*x*x; up=2*b*x; upp=2*b
    v=s**(-2.5); vp=-5*x*s**(-3.5); vpp=-5*s**(-3.5)+35*x*x*s**(-4.5)
    return (up*v+u*vp)/a,(upp*v+2*up*vp+u*vpp)/a**2

# Phiprime=g. Integrate in log r, then invert phi(r).
logr=np.linspace(np.log(a*1e-7),np.log(a*1e8),16001)
rgrid=np.exp(logr); pgrid=np.r_[0,cumulative_trapezoid(g(rgrid)*rgrid,logr)]
phi=PchipInterpolator(logr,pgrid,extrapolate=False)
inv=PchipInterpolator(pgrid,logr,extrapolate=False)
C=1/(np.sqrt(8)*np.pi**2)

def df(E,q):
    # Abel inversion: f(E) = C int_E^inf rho_aug''(Phi) /sqrt(Phi-E) dPhi
    # substitute ln(r/r_E)=t² to remove endpoint singularity
    le=float(inv(E)); tmax=np.sqrt(logr[-1]-le)
    def integrand(t):
        if t==0: t=1e-9
        lr=le+t*t; r=np.exp(lr); gg=g(r); gp=dg(r)
        rp,rpp=derivs(r,q)
        rho2=(rpp*gg-rp*gp)/gg**3
        dphi=max(float(phi(lr)-E),1e-28)
        return rho2*gg*2*t*r/np.sqrt(dphi)
    return C*quad(integrand,0,tmax,epsabs=3e-10,epsrel=2e-6,limit=180)[0]

qs=[.5,.6,np.sqrt(2/5),.65,.7,.75,1.,1.5,2.,5.,np.inf]
# Energies corresponding to r/a, concentrating on inner and outer phase-space regions.
rr=a*np.geomspace(.015,300,43); Es=np.array([float(phi(np.log(r))) for r in rr])
rows=[]
for q in qs:
    vals=[df(E,q) for E in Es]
    scale=max(abs(v) for v in vals)
    negative=[i for i,v in enumerate(vals) if v < -1e-7*scale]
    rows.append({'ra_over_a':'isotropic' if np.isinf(q) else float(q),'n_energy':len(vals),'min_df':float(min(vals)),'max_df':float(max(vals)),'min_df_over_maxabs':float(min(vals)/scale),'negative_energy_points':len(negative),'first_negative_r_over_a':float(rr[negative[0]]/a) if negative else '', 'grid_nonnegative':not bool(negative)})
    print(q, 'min/max',min(vals),max(vals),'neg',len(negative),flush=True)
    for r,E,v in zip(rr,Es,vals):
        pass
    if q in [.5,.6,.65,.7,.75,1.,np.inf]:
        with (P/('df_q_'+('inf' if np.isinf(q) else str(q).replace('.','p'))+'.csv')).open('w',newline='') as f:
            w=csv.writer(f);w.writerow(['r_over_a','E_kms2','df_normalized']);w.writerows(zip(rr/a,Es,vals))
with (P/'df_positivity_scan.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Numeric consistency: compare two integration resolutions via repeated adaptive quadrature on selected points.
checks=[]
for q in [.7,1.,np.inf]:
    for rv in [.05,1.,10.]:
        E=float(phi(np.log(a*rv))); v=df(E,q)
        checks.append({'ra_over_a':str(q),'r_over_a':rv,'E':E,'f':v})
with (P/'spot_checks.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(checks[0]));w.writeheader();w.writerows(checks)
summary={'model':{'a_pc':a,'M_Msun':M,'a0_kms2_per_pc':a0,'nu':'simple','external_field':0},'inversion':'unbounded-potential Abel inversion, E=v²/2+Phi, Phi(0)=0; f(E)=1/(sqrt(8) pi²) integral_E^infinity d²rho_aug/dPhi² /sqrt(Phi-E) dPhi','samples':rows,'limits':['finite radial numerical upper limit r/a=1e8 (tail not analytically completed)','energy sample range r/a=0.015 to 300; not an all-energy positivity proof','no density reconstruction performed','spherical isolated QUMOND only, no external field','not UDCT-specific or Hydrus I direct fit','not v7.13 24-candidate audit']}
(P/'results.json').write_text(json.dumps(summary,indent=2))
print('DONE')
